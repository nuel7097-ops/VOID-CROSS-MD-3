/*
┏━━━━━━━━━━━━━━━┓
┃     ༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒𝐓𝐄𝐂𝐇
┣━━━━━━━━━━━━━━━┛
┃whatsapp : +2348063898506
┃owner : 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒
┃base : ༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒
┃best friend : 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒 
┃helper : my brain😂😂
┃maintainer : 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒
┃deals : t.me/cross006
┃pterodactyl hosting buy from 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒 dev
┗━━━━━━━━━━━━━━━┛
*/
require('./config')
const {
	𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒Connect,
	downloadContentFromMessage,
	emitGroupParticipantsUpdate,
	emitGroupUpdate,
	generateWAMessageContent,
	generateWAMessage,
	makeInMemoryStore,
	prepareWAMessageMedia,
	generateWAMessageFromContent,
	MediaType,
	areJidsSameUser,
	WAMessageStatus,
	downloadAndSaveMediaMessage,
	AuthenticationState,
	GroupMetadata,
	initInMemoryKeyStore,
	getContentType,
	MiscMessageGenerationOptions,
	useSingleFileAuthState,
	BufferJSON,
	WAMessageProto,
	MessageOptions,
	WAFlag,
	WANode,
	WAMetric,
	ChatModification,
	MessageTypeProto,
	WALocationMessage,
	ReconnectMode,
	WAContextInfo,
	proto,
	WAGroupMetadata,
	ProxyAgent,
	waChatKey,
	MimetypeMap,
	MediaPathMap,
	WAContactMessage,
	WAContactsArrayMessage,
	WAGroupInviteMessage,
	WATextMessage,
	WAMessageContent,
	WAMessage,
	BaileysError,
	WA_MESSAGE_STATUS_TYPE,
	MediaConnInfo,
	URL_REGEX,
	WAUrlInfo,
	WA_DEFAULT_EPHEMERAL,
	WAMediaUpload,
	mentionedJid,
	processTime,
	Browser,
	MessageType,
	Presence,
	WA_MESSAGE_STUB_TYPES,
	Mimetype,
	relayWAMessage,
	Browsers,
	GroupSettingChange,
	DisconnectReason,
	WASocket,
	getStream,
	WAProto,
	isBaileys,
	AnyMessageContent,
	fetchLatestBaileysVersion,
	templateMessage,
	InteractiveMessage,
	Header
} = require("@whiskeysockets/baileys")
const fs = require('fs')
const axios = require('axios')
const fetch = require('node-fetch')
const chalk = require('chalk')
const speed = require('performance-now')
const moment = require('moment-timezone')
const os = require('os')
const { spawn: spawn, exec } = require("child_process")
const crypto = require('crypto');
//=================================================//
module.exports = 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒 = handler = async (𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒, m, chatUpdate, store) => {
	try {
	
		const { smsg, formatp, tanggal, formatDate, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins } = require('./𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒bot/lib/function.js');
		const { toAudio, toPTT, toVideo, ffmpeg, addExifAvatar } = require('./𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒bot/lib/converter');
		const { TelegraPh, UploadFileUgu, webp2mp4File, floNime } = require('./𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒bot/lib/uploader');
        const { addPremiumUser, delPremiumUser } = require("./𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒bot/lib/premiun");
    //=================================================//
		var body = (
			m.mtype === 'conversation' ? m.message.conversation :
			m.mtype === 'imageMessage' ? m.message.imageMessage.caption :
			m.mtype === 'videoMessage' ? m.message.videoMessage.caption :
			m.mtype === 'extendedTextMessage' ? m.message.extendedTextMessage.text :
			m.mtype === 'buttonsResponseMessage' ? m.message.buttonsResponseMessage.selectedButtonId :
			m.mtype === 'listResponseMessage' ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
			m.mtype === 'interactiveResponseMessage' ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id :
			m.mtype === 'templateButtonReplyMessage' ? m.message.templateButtonReplyMessage.selectedId :
			m.mtype === 'messageContextInfo' ?
			m.message.buttonsResponseMessage?.selectedButtonId ||
			m.message.listResponseMessage?.singleSelectReply.selectedRowId ||
			m.message.InteractiveResponseMessage.NativeFlowResponseMessage ||
			m.text :
			''
			);
		if (body == undefined) { body = '' };
		var budy = (typeof m.text == "string" ? m.text : "");
    //=================================================//
		//command
		const prefixRegex = /[.!#÷×/]/;
		const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : null;
		const isCmd = prefix ? body.startsWith(prefix) : false;
		const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';		
		const args = budy.trim().split(/ +/).slice(1);
const q = text = args.join(" ")
		// Individual
const premuser = JSON.parse(fs.readFileSync("./𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒bot/database/premium.json"));
		const botNumber = 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.user.id.split(':')[0];
		const pushname = m.pushName || "No Name";
		const senderNumber = m.sender.split('@')[0];
        const isPremium = botNumber || premuser.map(u => formatJid(u.id)).includes(m.sender);
		const itsMe = m.sender == botNumber;
		const isOwner = [botNumber, ...global.owner]
			.map(v => v.replace(/[^0-9]/g, "") + "@s.whatsapp.net")
			.includes(m.sender);
			
		if (!𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.public) {
			if (!m.fromMe && !isOwner) return;
		};

		// Group
		const isGroup = m.chat.endsWith('@g.us');
		const groupMetadata = isGroup ? await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupMetadata(m.chat).catch(e => {}) : '';
		const groupName = isGroup ? groupMetadata.subject : '';
		const groupMembers = isGroup ? groupMetadata.participants : '';
		const groupAdmins = isGroup ? await getGroupAdmins(groupMembers) : '';
		const isBotAdmin = isGroup ? groupAdmins.includes(botNumber + '@s.whatsapp.net') : false;
		const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
		const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
		const groupOwner = isGroup ? groupMetadata.owner : '';
		const isGroupOwner = isGroup ? (groupOwner ? groupOwner : groupAdmins).includes(m.sender) : false;

		//msg
		const isMedia = (m.type === 'imageMessage' || m.type === 'videoMessage')
		const fatkuns = (m.quoted || m)
		const quoted = (fatkuns.mtype == "buttonsMessage") ? fatkuns[Object.keys(fatkuns)[1]] : (fatkuns.mtype == "templateMessage") ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] : (fatkuns.mtype == "product") ? fatkuns[Object.keys(fatkuns)[0]] : m.quoted ? m.quoted : m
		const qmsg = (quoted.msg || quoted)
		const mime = qmsg.mimetype || "";
		const fake = fs.readFileSync('./𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒bot/media/moon.jpeg')
		const trash= fs.readFileSync('./𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒bot/media/𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.jpeg')

		//time
		const time = moment().tz("Africa/Nairobi").format("HH:mm:ss");
		let ucapanWaktu;
		if (time >= "19:00:00" && time < "23:59:00") {
			ucapanWaktu = "夜 🌌";
		} else if (time >= "15:00:00" && time < "19:00:00") {
			ucapanWaktu = "午後 🌇";
		} else if (time >= "11:00:00" && time < "15:00:00") {
			ucapanWaktu = "正午 🏞️";
		} else if (time >= "06:00:00" && time < "11:00:00") {
			ucapanWaktu = "朝 🌁";
		} else {
			ucapanWaktu = "夜明け 🌆";
		}
		const wib = moment(Date.now()).tz("Africa/Nairobi").locale("id").format("HH:mm:ss z");
		const wita = moment(Date.now()).tz("Africa/Nairobi").locale("id").format("HH:mm:ss z");
		const wit = moment(Date.now()).tz("Africa/Nairobi").locale("id").format("HH:mm:ss z");
		const salam = moment(Date.now()).tz("Africa/Nairobi").locale("id").format("a");
		let d = new Date();
		let gmt = new Date(0).getTime() - new Date("1 Januari 2024").getTime();
		let weton = ["Pahing", "Pon", "Wage", "Kliwon", "Legi"][Math.floor(((d * 1) + gmt) / 84600000) % 5];
		let week = d.toLocaleDateString("id", { weekday: "long" });
		let calendar = d.toLocaleDateString("id", {
			day: "numeric",
			month: "long",
			year: "numeric"
		});		

        //quoted
		const ctt = {
			key: {
				remoteJid: '0@s.whatsapp.net',
				participant: '0@s.whatsapp.net',
				fromMe: false,
			},
			message: {
				contactMessage: {
					displayName: (pushname),
					vcard: `BEGIN:VCARD\nVERSION:3.0\nN:XL;${pushname},;;;\nFN:${pushname}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
				}
			}
		};

		const callg = {
			key: {
				remoteJid: 'status@broadcast',
				participant: '0@s.whatsapp.net',
				fromMe: false,
			},
			message: {
				callLogMesssage: {
                    isVideo: true,
                    callOutcome: "1",
                    durationSecs: "0",
                    callType: "REGULAR",
                    participants: [{ jid: "0@s.whatsapp.net", callOutcome: "1" }]
                }
			}
		};

        //reply
		const xreply = async (teks) => {
			await sleep(500)
			return 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
				contextInfo: {
					mentionedJid: [
						m.sender
					],
					externalAdReply: {
						showAdAttribution: false, 
						renderLargerThumbnail: false, 
						title: `slayqueen`,
						body: `By 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒`,
						previewType: "VIDEO",
						thumbnail: fake,
						sourceUrl: global.url,
						mediaUrl: global.url
					}
				},
				text: teks
			}, {
				quoted: ctt
			})
		}
𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.public = true;
  
  // Call detection block
  // Map<userId+groupId, timestamp>

𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.ev.on('group-participants.update', async (update) => {
  try {
    const metadata = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupMetadata(update.id);
    const participants = update.participants;

    for (const user of participants) {
      const cacheKey = `${user}_${update.id}`;
      const now = Date.now();

      if (update.action === 'add' && global.welcome) {
        // Prevent duplicate welcomes
        if (recentJoins.has(cacheKey) && now - recentJoins.get(cacheKey) < 10000) {
          continue; // skip if already welcomed in last 10 seconds
        }
        recentJoins.set(cacheKey, now);

        const ppuser = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.profilePictureUrl(user, 'image').catch(_ => 'https://i.ibb.co/rx5DFbs/profile-unknown.png');
        const name = metadata.subject;
        const member = metadata.participants.length;

        const text = `╭─❖
│ 🎉 *Welcome* @${user.split("@")[0]}
│ 🏷️ Group: *${name}*
│ 👥 Members: *${member}*
╰──⭔ *Introduce yourself!*`;

        await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(update.id, {
          image: { url: ppuser },
          caption: text,
          mentions: [user]
        });

        // Optional: Clear the cache after 30 seconds
        setTimeout(() => recentJoins.delete(cacheKey), 30000);
      }

      if (update.action === 'remove' && global.welcome) {
        const text = `╭─❖
│ 👋 *Goodbye* @${user.split("@")[0]}
│ 🏷️ Group: *${metadata.subject}*
╰──⭔ *We'll miss you!*`;

        await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(update.id, {
          text,
          mentions: [user]
        });
      }
    }
  } catch (err) {
    console.log('WELCOME ERROR:', err);
  }
});
  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.ev.on('call', async ({ from }) => {
    if (global.detectCall) {
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(from, { text: '🚫 You called the bot. You will be blocked.' })
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.updateBlockStatus(from, 'block')
    }
  })

  // Auto-block untrusted users
  function isTrustedUser(jid) {
    const allowed = ['2348063898506@s.whatsapp.net']
    return allowed.includes(jid)
  }

  if (global.autoBlock && !isOwner && !m.isGroup && !isTrustedUser(m.sender)) {
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.updateBlockStatus(m.sender, 'block')
    console.log(`Auto-blocked ${m.sender}`)
  }
const reply = async (teks) => {
			await sleep(500)
			return 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
				contextInfo: {
					mentionedJid: [
						m.sender
					],
					externalAdReply: {
						showAdAttribution: false, 
						renderLargerThumbnail: false, 
						title: `slayqueen`,
						body: `By 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒`,
						previewType: "VIDEO",
						thumbnail: fake,
						sourceUrl: global.url,
						mediaUrl: global.url
					}
				},
				text: teks
			}, {
				quoted: ctt
			})
		}
  // Default reply with rich context
  
  // Anti-link detection
  const handleAntiLink = async (m, 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒) => {
    if (!m.isGroup || isAdmins || isOwner || !db.data.antilink || !db.data.antilink[m.chat]) return
    const linkDetected = /https:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]{20,24}/gi.test(m.body)
    if (linkDetected) {
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
        text: `┏━━━━━━━━━━❐\n┃ 🚫 *Link Detected!*\n┃ @${m.sender.split('@')[0]} posted a WhatsApp link.\n┃ 👢 Kicking user...`,
        mentions: [m.sender]
      })
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupParticipantsUpdate(m.chat, [m.sender], 'remove').catch(() => reply('❌ Failed to kick the user.'))
    }
  }

  // Auto React 2 in group
  const handleAutoReact2 = async (m, 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒) => {
    const autoReactOn = db?.data?.autoreact2?.[m.chat]
    if (!autoReactOn || m.key.fromMe || m.isGroup === false) return
    const emojis = ['😎', '🔥', '😂', '👍', '😮', '💀', '🥵', '🥴', '🤓', '🤑', '👻', '❤️', '💯']
    const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)]
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { react: { text: randomEmoji, key: m.key } }).catch(() => {})
  }

  // Bot detection in group joins
  const handleBotDetection = async (update) => {
    try {
      const metadata = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupMetadata(update.id)
      const groupAdmins = metadata.participants.filter(p => p.admin).map(p => p.id)
      if (update.action === 'add') {
        for (const user of update.participants) {
          const isLikelyBot = (
            user.endsWith('bot@c.us') || user.includes(':') || user.toLowerCase().includes('bot') || user.length < 15
          )
          if (isLikelyBot && groupAdmins.includes(botNumber)) {
            await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupParticipantsUpdate(update.id, [user], 'remove')
            await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(update.id, {
              text: `┏━━━━━━━━━━❐\n┃ 🤖 *Bot Detected!*\n┃ 🚫 @${user.split('@')[0]} has been kicked.\n┃ 📌 *Only verified human users are allowed.*\n┗━━━━━━━━━━❐`,
              mentions: [user]
            })
          }
        }
      }
    } catch (err) {
      console.log('❌ Bot AutoKick Error:', err)
    }
  }
if (isCmd) {
  console.log(chalk.hex('#4a69bd').bold(`
┌───────────────────────────────┐
│ 🚀 SLAYQUEEN 🚀
├───────────────────────────────┤
│ 📅 ${chalk.hex('#fdcb6e').bold(time)}
│ 💬 ${chalk.hex('#fdcb6e').bold(command)}
│ 🗣️ ${chalk.hex('#fdcb6e').bold(pushname)}
│ 👤 ${chalk.hex('#fdcb6e').bold(m.sender)}
└───────────────────────────────┘
`));
}
  // Single autoReact (outside group)
  
  if (global.autoReact && !m.key.fromMe && !m.isGroup) {
    const emojis = ['🌷', '🔥', '💀', '👀', '😂', '🥺', '💎', '💯', '🥶', '🎮', '🚀']
    const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)]
    try {
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { react: { text: randomEmoji, key: m.key } })
    } catch (e) {
      console.error("React Failed:", e)
    }
  }
//START-UP CODES
//=============================
switch (command) {
case 'starter': {
  await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
    react: { text: "🥺", key: m.key }
  })

  let timestamp = speed()
  let latensi = speed() - timestamp
  let run = runtime(process.uptime())

  let caption = ` 
  
  \`❰❴ ⎈ 𝗦𝗟𝗔𝗬𝗤𝗨𝗘𝗘𝗡 𝗔𝗜 ⎈ ❵❱\`
┏━━━━━━━━━━━━━━❏
┃✪ 𝗕𝗢𝗧: \`❰❴ ⎈ 𝗦𝗟𝗔𝗬𝗤𝗨𝗘𝗘𝗡 𝗔𝗜 ⎈ ❵❱\`
┃✪ 𝗨𝗦𝗘𝗥: ${pushname}
┃✪ 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥: 𝐌𝐑.𝐂𝐑𝐎𝐒𝐒
┗━━━━━━━━━━━━━━❏
> follow channel for updates🙏

‎Open this link to join my WhatsApp Group: https://chat.whatsapp.com/FE2i3pSKFB9GZSTW2DYUzQ?s=sh&p=i&ilr=1
\`OWNER COMMANDS\`
┏━━━━━━━━━━━━━━❂
┃ 
┃❒ Public
┃❒ Private
┃❒ Block
┃❒ Unblock
┃❒ Clearchat
┃❒ Broadcast
┃❒ Bc
┃❒ detectcall
┃❒ autoreadpm
┃❒ autoonline
┃❒ autobio
┃❒ autoreadgc
┃❒ autorecordgc
┃❒ autotypinggc
┃❒ autoread 
┗━━━━━━━━━━━━━━❂


\`NEWSLETTER\`
┏━━━━━━━━━━━━━━❂
┃ 
┃❒ creategc
┃❒ createchannel
┃❒ idch
┃❒ postchannel
┃❒ channeldetails
┃❒ mychannels
┃❒ subscribech
┃❒ unsubscribech
┃❒ channeldesc
┃❒ previewchannel 
┗━━━━━━━━━━━━━━❂


\`PREMIUM FEATURES\`
┏━━━━━━━━━━━━━━❂
┃❒ slayx
┃❒ delayinvis
┃❒ gcbye
┃❒ ios-attack
┃❒ 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒sung-1
┃❒ force-close
┃❒ x𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒
┃❒ terminate
┗━━━━━━━━━━━━━━❂


\`GROUP\`
┏━━━━━━━━━━━━━━❂
┃  
┃❒ Tagall
┃❒ Hidetag
┃❒ Add
┃❒ Kick
┃❒ Promote
┃❒ Demote
┃❒ Del
┃❒ Invite
┃❒ Vcf
┃❒ Gc
┃❒ Revoke
┃❒ Grouplink
┃❒ Setname
┃❒ Setdesc
┃❒ Tagadmin
┃❒ Totag
┃❒ masskick
┃❒ pingall
┃❒ warn
┃❒ resetwarn
┃❒ lockgroup
┃❒ groupaudit
┗━━━━━━━━━━━━━━❂


\`AI/GPT GEN\`
┏━━━━━━━━━━━━━━❂
┃  
┃❒ Chatgpt
┃❒ Ai
┃❒ Tiny
┃❒ Quotes
┃❒ Fact
┃❒ Truth
┃❒ Pickupline
┗━━━━━━━━━━━━━━❂


\`DOWNLOAD\`
┏━━━━━━━━━━━━━━❂
┃  
┃❒ Play
┃❒ Splay
┃❒ Song
┃❒ Video
┃❒ Spotify-search
┃❒ Spoty-download
┃❒ Yts
┃❒ Facebook
┃❒ Instagram
┃❒ Tiktok
┃❒ Aio
┃❒ Mediafire
┗━━━━━━━━━━━━━━❂


\`LOVE ZONE\`
┏━━━━━━━━━━━━━━❂
┃❒ pickup
┃❒ loveadv
┃❒ cutename
┃❒ lovefact
┃❒ lovequote
┃❒ lovepoem
┃❒ romanticwish
┃❒ loveletter
┗━━━━━━━━━━━━━━❂


\`FUN\`
┏━━━━━━━━━━━━━━❂
┃❒ 8ball
┃❒ Roast
┃❒ Food
┃❒ Advice
┃❒ Rate
┃❒ Colour
┃❒ Ship
┃❒ Emoji
┃❒ Vowels
┃❒ Reverse
┗━━━━━━━━━━━━━━❂


\`TOOLS\`
┏━━━━━━━━━━━━━━❂
┃  
┃❒ Ssweb
┃❒ Gitclone
┃❒ Short
┃❒ Tts
┃❒ Hackertyper
┃❒ Qrcode
┃❒ Reminder
┃❒ Emojimix
┃❒ Repeat
┗━━━━━━━━━━━━━━❂


\`MEDIA\`
┏━━━━━━━━━━━━━━❂
┃  
┃❒ Sticker
┃❒ Stickerinfo
┃❒ Img
┃❒ Anime
┃❒ Getpp
┃❒ S
┃❒ Status
┃❒ Profile
┗━━━━━━━━━━━━━━❂


\`INFO/SYSTEM\`
┏━━━━━━━━━━━━━━❂
┃  
┃❒ Uptime
┃❒ Repo
┃❒ Info
┃❒ Myip
┃❒ Week
┃❒ ping3
┃❒ Listonline
┗━━━━━━━━━━━━━━❂


\`AUDIO EFFECTS\`
┏━━━━━━━━━━━━━━━━━❂
┃❒ bass
┃❒ slow
┃❒ fast
┃❒ robot
┃❒ nightcore
┗━━━━━━━━━━━━━━❂

\`NEW\`
┏━━━━━━━━━━━━━━━━━❂
┃  
┃❒ spy
┃❒ myname
┃❒ creator
┃❒ package 
┃❒ motivate
┃❒ rate
┃❒ vibe
┃❒ randomnumber
┃❒ listdead
┃❒ kickdead
┃❒ buyprem
┃❒ source 
┃❒ rules
┃❒ suggest
┃❒ donate
┃❒ friends 
┃❒ ping2
┃❒ addfriend 
┃❒ k
┃❒ docinfo
┃❒ compressing
┃❒ topdf
┃❒ removefriend
┗━━━━━━━━━━━━━━━━❂


\`NOT TESTED\`
┏━━━━━━━━━━━━━━━━━━━━━❂
┃  
┃❒ save
┃❒ autoreact
┃❒ autoviewstatus
┃❒ blocklist
┃❒ autoblock
┃❒ tempblock
┃❒ isblocked
┃❒ clearblocks
┗━━━━━━━━━━━━━━━━━━━━━━━❂


\`FORTUNE/ZODIAC CMD\`
┏━━━━━━━━━━━━━━━━━━━━━❂
┃❒ fortune
┃❒ luck
┃❒ yesno
┃❒ dailyfortune
┃❒ fortunecolour
┃❒ howgay
┃❒ simprate
┃❒ zodiac
┃❒ compatibility
┃❒ element
┃❒ luckycolour
┃❒ luckyday
┗━━━━━━━━━━━━━━━━━━━━━━━❂


\`DEV MENUS\`
┏━━━━━━━━━━━━━━━━━━━━━❂
┃❒ getjid
┃❒ memory
┃❒ restart
┃❒ getname
┃❒ speed
┃❒ base64encode
┃❒ base64decode
┃❒ iplookup
┃❒ screenshot
┃❒ uuid
┃❒ timestump
┃❒ headers
┃❒ env
┃❒ randomport
┃❒ md5
┃❒ sha256
┃❒ baseurl 
┃❒ pingurl
┃❒ jsbeautify
┃❒ eval
┃❒ getheaders 
┃❒ useragent
┗━━━━━━━━━━━━━━━━━━━━━━━❂

𝗧𝗛𝗜𝗦 𝗜𝗦 𝗦𝗟𝗔𝗬𝗤𝗨𝗘𝗘𝗡 𝗕𝗢𝗧 𝗖𝗥𝗘𝗔𝗧𝗘𝗗 𝗕𝗬 ༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒
> powered by ༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒 `

  let menuImage = 'https://files.catbox.moe/9liluf.jpg'
  
  await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
    image: { url: menuImage },
    caption: caption,
    contextInfo: {
      forwardingScore: 9,
      isForwarded: false,
      forwardedNewsletterMessageInfo: {
        newsletterName: "𝘀𝗹𝗮𝘆𝗾𝘂𝗲𝗲𝗻",
        newsletterJid: "120363351424590490@newsletter",
      },
      externalAdReply: {
        title: `𝘀𝗹𝗮𝘆𝗾𝘂𝗲𝗲𝗻`,
        body: `Join our official channel for update`,
        thumbnailUrl: `https://files.catbox.moe/2ka6qw.jpeg`,
        sourceUrl: `https://whatsapp.com/channel/0029VaXaqHII1Bsd3g`,
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  }, { quoted: ctt })

  await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
    audio: { url: 'https://files.catbox.moe/bcxrjt.mp3' },
    mimetype: 'audio/mpeg'
  }, { quoted: ctt })
}
break
case 'idch': case 'cekid': {
  if (!text) return m.reply("❌ Channel link?");
  if (!text.includes("https://whatsapp.com/channel/")) return m.reply("❌ Link must be valid");

  try {
    let result = text.split("https://whatsapp.com/channel/")[1];
    let res = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.newsletterMetadata("invite", result);

    let teks = `📡 *Channel Info*
────────────────
✨ *ID:* ${res.id}
📛 *Name:* ${res.name}
👥 *Followers:* ${res.subscribers}
📌 *Status:* ${res.state}
✔️ *Verified:* ${res.verification === "VERIFIED" ? "Yes ✅" : "No ❌"}`;

    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(
      m.chat,
      {
        text: teks,
        contextInfo: {
          mentionedJid: [m.sender],
          externalAdReply: {
            title: res.name,
            body: "slayqueen md the best wa bot in 2026",
            thumbnailUrl: res.picture || "https://telegra.ph/file/3e8a4b03d9b35d6a7b1f3.jpg",
            sourceUrl: `https://whatsapp.com/channel/${result}`,
            mediaType: 1,
            renderLargerThumbnail: false
          }
        }
      },
      { quoted: ctt }
    );

  } catch (e) {
    console.error(e);
    m.reply("❌ Failed to fetch channel metadata.");
  }
}
break;
case 'welcome': {
  if (!m.isGroup) return reply('Group only command.');
  if (!isAdmins && !isOwner) return reply('Only admins or owner can use this.');

  if (args[0] === 'on') {
    global.welcome = true;
    reply('✅ Welcome messages *enabled*.');
  } else if (args[0] === 'off') {
    global.welcome = false;
    reply('❌ Welcome messages *disabled*.');
  } else {
    reply(`Use: *${prefix}welcome on/off*`);
  }
}
break;
case 'antilink': {
  if (!m.isGroup) return reply(`┏━━━━━━━━━━❐\n┃ ⚠️ This command works *only in groups*.\n┗━━━━━━━━━━❐`);
  if (!isAdmins && !isOwner) return reply(`┏━━━━━━━━━━❐\n┃ ❌ Only *admins* can toggle this feature.\n┗━━━━━━━━━━❐`);

  const toggleAntilink = (chatId) => {
    db.data.antilink = db.data.antilink || {};
    db.data.antilink[chatId] = !db.data.antilink[chatId];
    return db.data.antilink[chatId];
  };

  const status = toggleAntilink(m.chat);

  reply(
    `┏━━━━━━━━━━❐\n` +
    `┃ 🔗 *Anti-Link Mode*\n` +
    `┃ Status: ${status ? '✅ Enabled' : '❌ Disabled'}\n` +
    `┗━━━━━━━━━━❐`
  );
}
break;
case 'autoreact2': {
  if (!isOwner) return reply(
    `┏━━━━━━━━━━❐\n` +
    `┃ 🚫 *Owner Only Command*\n` +
    `┗━━━━━━━━━━❐`
  );

  const toggleAutoReact2 = (chatId) => {
    db.data.autoreact2 = db.data.autoreact2 || {};
    db.data.autoreact2[chatId] = !db.data.autoreact2[chatId];
    return db.data.autoreact2[chatId];
  };

  const status = toggleAutoReact2(m.chat);

  reply(
    `┏━━━━━━━━━━❐\n` +
    `┃ 🤖 *AutoReact v2 Mode*\n` +
    `┃ Status: ${status ? '✅ Enabled' : '❌ Disabled'}\n` +
    `┗━━━━━━━━━━❐`
  );
}
break;
case 'antibot': {
  if (!m.isGroup) return reply(`┏━━━━━━━━━━❐
┃ 📍 *This command only works in groups.*
┗━━━━━━━━━━❐`)
  if (!isAdmins && !isOwner) return reply(`┏━━━━━━━━━━❐
┃ ⛔ *Only admins can toggle AntiBot.*
┗━━━━━━━━━━❐`)

  const mode = (args[0] || '').toLowerCase()
  if (!['on', 'off'].includes(mode)) return reply(`┏━━━━━━━━━━❐
┃ ⚙️ *Usage:* antibot on / off
┗━━━━━━━━━━❐`)

  db.data.chats[from].antibot = mode === 'on'
  reply(`┏━━━━━━━━━━❐
┃ ✅ *AntiBot is now:* *${mode.toUpperCase()}*
┗━━━━━━━━━━❐`)
}
break
case 'romanticwish': {
  const wishes = [
    'May your heart always find peace in love ❤️',
    'Wishing you a forever filled with smiles and cuddles 😊',
    'May your love story be as sweet as a fairytale ✨',
    'Hope your days are filled with small kisses and big hugs 💞'
  ];
  reply(`┏━━━━━━━━━━❐
┃ 🌟 Romantic Wish:
┃     ${wishes[Math.floor(Math.random() * wishes.length)]}
┗━━━━━━━━━━❐`);
}
break;
case 'loveletter': {
  const loveLetters = [
`┏━━━━━━━━━━❐
┃ 💌 *Love Letter #1*
┃ I never knew what true love was until I met you.
┃ You are my today and all of my tomorrows.
┗━━━━━━━━━━❐`,

`┏━━━━━━━━━━❐
┃ 💌 *Love Letter #2*
┃ No matter the distance between us,
┃ my heart will always find its way to you.
┗━━━━━━━━━━❐`,

`┏━━━━━━━━━━❐
┃ 💌 *Love Letter #3*
┃ You're not just someone I love—
┃ you're the reason I breathe.
┗━━━━━━━━━━❐`,

`┏━━━━━━━━━━❐
┃ 💌 *Love Letter #4*
┃ I wrote your name in the sky,
┃ but the wind blew it away.
┃ I wrote your name in my heart, and there it will stay.
┗━━━━━━━━━━❐`,

`┏━━━━━━━━━━❐
┃ 💌 *Love Letter #5*
┃ If kisses were stars, I'd give you the galaxy.
┃ If hugs were waves, you'd drown in my ocean.
┗━━━━━━━━━━❐`,

`┏━━━━━━━━━━❐
┃ 💌 *Love Letter #6*
┃ When I say I love you more,
┃ I don’t mean I love you more than you love me.
┃ I mean I love you more than the bad days ahead.
┗━━━━━━━━━━❐`,

`┏━━━━━━━━━━❐
┃ 💌 *Love Letter #7*
┃ I fall for you more every day—
┃ in the little smiles, the quiet moments, and the laughs we share.
┗━━━━━━━━━━❐`,

`┏━━━━━━━━━━❐
┃ 💌 *Love Letter #8*
┃ Even forever wouldn’t be long enough with you.
┃ You make life worth living.
┗━━━━━━━━━━❐`,

`┏━━━━━━━━━━❐
┃ 💌 *Love Letter #9*
┃ I never believed in soulmates until you showed up.
┃ Now I believe in magic, destiny, and us.
┗━━━━━━━━━━❐`,

`┏━━━━━━━━━━❐
┃ 💌 *Love Letter #10*
┃ My favorite place in the world is next to you.
┃ Your love is my strength, my peace, my everything.
┗━━━━━━━━━━❐`,
  ];

  if (!args[0]) {
    return reply(
`┏━━❐ *Love Letters Menu*
┃ Type: *.loveletter [1-10]*
┃ Example: *.loveletter 4*
┃ 
┃ 📮 Letters Available:
┃ 1 — Sweet love
┃ 2 — Long-distance
┃ 3 — Breathless
┃ 4 — Eternal heart
┃ 5 — Starry kiss
┃ 6 — More than love
┃ 7 — Quiet romance
┃ 8 — Forever vow
┃ 9 — Soulmates
┃ 10 — You & Me
┗━━━━━━━━━━❐
> powered by *𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒dev*`
    );
  }

  let index = parseInt(args[0]) - 1;
  if (isNaN(index) || index < 0 || index >= loveLetters.length) {
    return reply(`❌ Invalid choice. Please use *.loveletter 1* to *.loveletter 10*`);
  }

  return reply(loveLetters[index]);
}
case 'lovequote': {
  const quotes = [
    `┏━━━━━━━━━━❐
┃ 💖 "Love is not about how many days,
┃     but how much you love each day."
┗━━━━━━━━━━❐`,

    `┏━━━━━━━━━━❐
┃ 💖 "In you, I’ve found my heart’s home."
┗━━━━━━━━━━❐`,

    `┏━━━━━━━━━━❐
┃ 💖 "I didn’t choose you. My heart did."
┗━━━━━━━━━━❐`
  ];
  const pick = quotes[Math.floor(Math.random() * quotes.length)];
  reply(pick);
}
break;
case 'lovepoem': {
  const poem = `┏━━━━━━━━━━❐
┃ 🌹 In your eyes, I see my dawn,
┃     In your heart, my peace is drawn.
┃     Every breath I take feels new,
┃     Since the day I fell for you.
┗━━━━━━━━━━❐`;
  reply(poem);
}
break;
case 'lovefact': {
  const facts = [
    `┏━━━━━━━━━━❐
┃ 💘 Falling in love releases dopamine—
┃     the 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒e chemical as chocolate!
┗━━━━━━━━━━❐`,
    `┏━━━━━━━━━━❐
┃ 💘 Eye contact with your partner
┃     syncs your heartbeats.
┗━━━━━━━━━━❐`
  ];
  reply(facts[Math.floor(Math.random() * facts.length)]);
}
break;
case 'cutename': {
  const names = ['Honeybun 🍯', 'Snugglebug 🐞', 'Moonpie 🌙', 'Pumpkin 🎃', 'Angelface 😇'];
  const name = names[Math.floor(Math.random() * names.length)];
  reply(
    `┏━━━━━━━━━━❐
┃ 🥰 Your cute nickname is:
┃     ${name}
┗━━━━━━━━━━❐`
  );
}
break;
case 'loveadv': {
  const tips = [
    `┏━━━━━━━━━━❐
┃ 💡 Always listen more than you speak.
┗━━━━━━━━━━❐`,
    `┏━━━━━━━━━━❐
┃ 💡 Make time, not excuses.
┗━━━━━━━━━━❐`,
    `┏━━━━━━━━━━❐
┃ 💡 Respect their space and dreams.
┗━━━━━━━━━━❐`
  ];
  reply(tips[Math.floor(Math.random() * tips.length)]);
}
break;
case 'pickup': {
  const pickupLines = [
    `┏━━━━━━━━━━❐
┃ 💬 Are you a magician?
┃     Because whenever I look at you, everyone else disappears.
┃ 💬 Is your name Google?
┃     Because you’ve got everything I’ve been searching for.
┗━━━━━━━━━━❐`,

    `┏━━━━━━━━━━❐
┃ 💬 Do you have a map?
┃     Because I keep getting lost in your eyes.
┃ 💬 Are you a time traveler?
┃     Because I see you in my future.
┗━━━━━━━━━━❐`,

    `┏━━━━━━━━━━❐
┃ 💬 If beauty were a crime,
┃     You’d be serving a life sentence.
┃ 💬 Are you a charger?
┃     Because without you, I die.
┗━━━━━━━━━━❐`,

    `┏━━━━━━━━━━❐
┃ 💬 Are you made of copper and tellurium?
┃     Because you’re Cu-Te.
┃ 💬 Is it hot in here,
┃     Or is it just you?
┗━━━━━━━━━━❐`,

    `┏━━━━━━━━━━❐
┃ 💬 Can you lend me a kiss?
┃     I promise I’ll give it back.
┃ 💬 Are you French?
┃     Because Eiffel for you.
┗━━━━━━━━━━❐`,

    `┏━━━━━━━━━━❐
┃ 💬 Are you a campfire?
┃     Because you’re hot and I want s’more.
┃ 💬 Do you have a pencil?
┃     Because I want to erase your past and write our future.
┗━━━━━━━━━━❐`,

    `┏━━━━━━━━━━❐
┃ 💬 If you were a vegetable,
┃     You’d be a cute-cumber.
┃ 💬 Are you a star?
┃     Because your light brightens up my life.
┗━━━━━━━━━━❐`,

    `┏━━━━━━━━━━❐
┃ 💬 Is your smile a spell?
┃     Because it enchanted me.
┃ 💬 Can I take you out?
┃     Because you definitely just swept me off my feet.
┗━━━━━━━━━━❐`,

    `┏━━━━━━━━━━❐
┃ 💬 Are you a volcano?
┃     Because I lava you.
┃ 💬 Are you gravity?
┃     Because I’m falling for you.
┗━━━━━━━━━━❐`,

    `┏━━━━━━━━━━❐
┃ 💬 Are you a sunrise?
┃     Because you brighten up my darkest mornings.
┃ 💬 Do you run track?
┃     Because you’ve been running through my mind all day.
┗━━━━━━━━━━❐`
  ];

  const randomLine = pickupLines[Math.floor(Math.random() * pickupLines.length)];
  reply(randomLine);
}
break;
case 'docinfo': {
if (!m.quoted || m.quoted.mtype !== 'documentMessage') return reply(`┌──「 ⚠️ ERROR 」
│ Reply to a document
└──────────────`)
let doc = m.quoted.message.documentMessage
reply(`
┌──「 📄 Document Info 」
│ 📎 Name: ${doc.fileName || 'Unknown'}
│ 📦 MIME: ${doc.mimetype}
│ 📏 Size: ${doc.fileLength} bytes
└──────────────`)
}
break
case 'compressimg': {
if (!m.quoted || m.quoted.mtype !== 'imageMessage') return reply(`┌──「 ⚠️ ERROR 」
│ Reply to an image
└──────────────`)
let buffer = await downloadMediaMessage(m.quoted)
let compressed = await compressImage(buffer) // You define compressImage()
conn.sendMessage(m.chat, { image: compressed, caption: '┌──「 📉 COMPRESSED 」\n│ Image optimized\n└──────────────' }, { quoted: m })
}
break
case 'topdf': {
if (!m.quoted || !/image|document/.test(m.quoted.mtype)) return reply(`┌──「 ⚠️ ERROR 」
│ Reply to an image or doc
└──────────────`)
let media = await downloadMediaMessage(m.quoted)
let filePath = `./${getRandom()}.pdf`
await createPDF(media, filePath) // You define createPDF()
conn.sendMessage(m.chat, { document: fs.readFileSync(filePath), fileName: 'converted.pdf', mimetype: 'application/pdf' }, { quoted: m })
fs.unlinkSync(filePath)
}
break
case 'fortune': {
  const fortunes = [
    'You will discover something new today.',
    'Luck is on your side, use it wisely.',
    'A stranger will bring you an unexpected gift.',
    'Challenges are opportunities in disguise.',
    'Trust your instincts — they are your power.',
    'Avoid conflict today, peace brings better results.',
    'Be patient. Something great is on the way.',
    'Your creativity will surprise even you today.',
    'Someone secretly admires your strength.',
    'A major decision will change your path forever.'
  ]
  let result = fortunes[Math.floor(Math.random() * fortunes.length)]
  reply(`
╭───⟪ 🔮 Fortune Says ⟫───⬣
│ ${result}
╰──────────────⬣`)
}
break;
case 'luck': {
  const percent = Math.floor(Math.random() * 101);
  reply(`
╭───⟪ 🍀 Today's Luck ⟫───⬣
│ ☘️ Luck Level: ${percent}%
│ Tip: Avoid risky decisions if below 40%.
╰──────────────⬣`)
}
break;
case 'yesno': {
  const answers = ['Yes', 'No', 'Maybe', 'Definitely', 'Not now', 'Ask again later'];
  let answer = answers[Math.floor(Math.random() * answers.length)];
  reply(`
╭───⟪ 🎱 Magic Answer ⟫───⬣
│ Question Response: ${answer}
│ ⌛ Trust your timing.
╰──────────────⬣`)
}
break;
case 'dailyfortune': {
  const list = [
    "🔺 Focus on your goals today.",
    "⚖️ Balance your energy and effort.",
    "🧠 New knowledge will benefit you.",
    "🛡️ Protect your peace at all costs.",
    "🎯 The universe aligns in your favor."
  ]
  let pick = list[Math.floor(Math.random() * list.length)];
  reply(`
╭───⟪ 📆 Daily Fortune ⟫───⬣
│ ${pick}
│ 💡 Refreshes every day.
╰──────────────⬣`)
}
break;
case 'fortunecolor': {
  const colors = ['Red', 'Green', 'Blue', 'Yellow', 'Purple', 'White', 'Black', 'Pink'];
  let color = colors[Math.floor(Math.random() * colors.length)];
  reply(`
╭───⟪ 🎨 Lucky Color ⟫───⬣
│ Your color today is: ${color}
│ ✨ Use it to attract positive energy.
╰──────────────⬣`)
}
break;
case 'howgay': {
  const percent = Math.floor(Math.random() * 101)
  reply(`
╭───⟪ 🌈 How Gay Are You? ⟫───⬣
│ 🤔 Gay Level: ${percent}%
│ 📌 Accuracy: Unverified 🧪
╰──────────────⬣`)
}
break;
case 'simprate': {
  const percent = Math.floor(Math.random() * 101)
  reply(`
╭───⟪ 💘 Simp Rate Scanner ⟫───⬣
│ 😳 Simp Level: ${percent}%
│ 💡 Advice: ${percent > 70 ? 'Touch grass now.' : 'You’re safe... for now.'}
╰──────────────⬣`)
}
break;
case 'zodiac': {
  const signs = {
    aries: '♈ Aries: Bold, brave, energetic',
    taurus: '♉ Taurus: Reliable, patient, sensual',
    gemini: '♊ Gemini: Curious, witty, adaptable',
    cancer: '♋ Cancer: Emotional, nurturing, intuitive',
    leo: '♌ Leo: Confident, dramatic, loyal',
    virgo: '♍ Virgo: Practical, analytical, kind',
    libra: '♎ Libra: Diplomatic, fair, charming',
    scorpio: '♏ Scorpio: Passionate, resourceful, intense',
    sagittarius: '♐ Sagittarius: Adventurous, honest, free-spirited',
    capricorn: '♑ Capricorn: Ambitious, disciplined, wise',
    aquarius: '♒ Aquarius: Innovative, independent, quirky',
    pisces: '♓ Pisces: Dreamy, compassionate, creative'
  }

  const input = args[0]?.toLowerCase()
  if (!input || !signs[input]) {
    return reply(`
╭───⟪ 🔮 Zodiac Info ⟫───⬣
│ Usage: zodiac [sign]
│ Example: zodiac leo
│ Signs: aries, taurus, gemini, cancer, leo, virgo
│        libra, scorpio, sagittarius, capricorn
│        aquarius, pisces
╰──────────────⬣`)
  }

  const vibe = ['⭐ Lucky day!', '⚠️ Stay calm today.', '💡 Creative spark ahead.', '🔥 Passion is high!', '💤 Low energy day.'][Math.floor(Math.random() * 5)]

  reply(`
╭───⟪ ✨ Zodiac Reading ⟫───⬣
│ Sign: ${input.charAt(0).toUpperCase() + input.slice(1)}
│ Info: ${signs[input]}
│ Vibe: ${vibe}
╰──────────────⬣`)
}
break;
case 'compatibility': {
  if (args.length < 2) return reply(`
╭───⟪ 💞 Zodiac Compatibility ⟫───⬣
│ Usage: compatibility [sign1] [sign2]
│ Example: compatibility leo aquarius
╰──────────────⬣`)

  let sign1 = args[0].toLowerCase()
  let sign2 = args[1].toLowerCase()

  const percent = Math.floor(Math.random() * 101)
  const status = percent > 80 ? '💍 Perfect match!' :
                 percent > 60 ? '💘 Good chemistry' :
                 percent > 40 ? '🤔 Worth a try' :
                 '🚫 Not ideal'

  reply(`
╭───⟪ 💖 Zodiac Compatibility ⟫───⬣
│ Pair: ${sign1} × ${sign2}
│ Score: ${percent}%
│ Status: ${status}
╰──────────────⬣`)
}
break;
case 'element': {
  const groups = {
    fire: ['aries', 'leo', 'sagittarius'],
    earth: ['taurus', 'virgo', 'capricorn'],
    air: ['gemini', 'libra', 'aquarius'],
    water: ['cancer', 'scorpio', 'pisces']
  }

  const input = args[0]?.toLowerCase()
  if (!input) return reply(`
╭───⟪ 🌍 Zodiac Element ⟫───⬣
│ Usage: element [sign]
│ Example: element taurus
╰──────────────⬣`)

  let found;
  for (let [element, signs] of Object.entries(groups)) {
    if (signs.includes(input)) {
      found = element.charAt(0).toUpperCase() + element.slice(1)
      break
    }
  }

  if (!found) return reply(`⚠️ Invalid sign. Please try again.`)

  reply(`
╭───⟪ 🌌 Zodiac Element ⟫───⬣
│ Sign: ${input}
│ Element: ${found}
╰──────────────⬣`)
}
break;
case 'luckycolor': {
  const input = args[0]?.toLowerCase()
  if (!input) return reply(`
╭───⟪ 🎨 Lucky Color ⟫───⬣
│ Usage: luckycolor [sign]
│ Example: luckycolor virgo
╰──────────────⬣`)

  const colors = ['Red', 'Blue', 'Green', 'Gold', 'Purple', 'White', 'Orange', 'Black']
  const color = colors[Math.floor(Math.random() * colors.length)]

  reply(`
╭───⟪ 🎯 Lucky Color ⟫───⬣
│ Sign: ${input}
│ Today’s Lucky Color: ${color}
╰──────────────⬣`)
}
break;
case 'luckyday': {
  const input = args[0]?.toLowerCase()
  if (!input) return reply(`
╭───⟪ 📆 Lucky Day ⟫───⬣
│ Usage: luckyday [sign]
│ Example: luckyday capricorn
╰──────────────⬣`)

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
  const lucky = days[Math.floor(Math.random() * days.length)]

  reply(`
╭───⟪ 🌟 Lucky Day ⟫───⬣
│ Sign: ${input}
│ This Week’s Lucky Day: ${lucky}
╰──────────────⬣`)
}
break;
case 'bass': {
  if (!m.quoted || !/audio/.test(m.quoted.mtype)) return reply(`
╭─⫷ Voice Edit: Bass ⫸
│ • Error: No audio found.
│ • Tip: Reply to an audio message.
╰──────────────────────`);

  let media = await m.quoted.download();
  let filename = getRandom('.mp3');
  fs.writeFileSync(filename, media);

  exec(`ffmpeg -i ${filename} -af "bass=g=10" out.mp3`, async (err) => {
    fs.unlinkSync(filename);
    if (err) return reply(`
╭─⫷ Voice Edit: Bass ⫸
│ • Status: ❌ Failed to apply bass.
╰──────────────────────`);

    let buff = fs.readFileSync('out.mp3');
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(from, {
      audio: buff, mimetype: 'audio/mp4', ptt: true
    }, { quoted: m });

    fs.unlinkSync('out.mp3');
    reply(`
╭─⫷ Voice Edit: Bass ⫸
│ • Status: ✅ Bass effect applied.
│ • Type: Audio
╰──────────────────────`);
  });
}
break;
case 'slow': {
  if (!m.quoted || !/audio/.test(m.quoted.mtype)) return reply(`
╭─⫷ Voice Edit: Slow ⫸
│ • Error: No audio found.
│ • Tip: Reply to an audio message.
╰──────────────────────`);

  let media = await m.quoted.download();
  let filename = getRandom('.mp3');
  fs.writeFileSync(filename, media);

  exec(`ffmpeg -i ${filename} -filter:a "atempo=0.5" out.mp3`, async (err) => {
    fs.unlinkSync(filename);
    if (err) return reply(`
╭─⫷ Voice Edit: Slow ⫸
│ • Status: ❌ Failed to slow audio.
╰──────────────────────`);

    let buff = fs.readFileSync('out.mp3');
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(from, {
      audio: buff, mimetype: 'audio/mp4', ptt: true
    }, { quoted: m });

    fs.unlinkSync('out.mp3');
    reply(`
╭─⫷ Voice Edit: Slow ⫸
│ • Status: ✅ Audio slowed down.
│ • Effect: 0.5x speed
╰──────────────────────`);
  });
}
break;
case 'fast': {
  if (!m.quoted || !/audio/.test(m.quoted.mtype)) return reply(`
╭─⫷ Voice Edit: Fast ⫸
│ • Error: No audio found.
│ • Tip: Reply to a voice note.
╰──────────────────────`);

  let media = await m.quoted.download();
  let filename = getRandom('.mp3');
  fs.writeFileSync(filename, media);

  exec(`ffmpeg -i ${filename} -filter:a "atempo=2.0" out.mp3`, async (err) => {
    fs.unlinkSync(filename);
    if (err) return reply(`
╭─⫷ Voice Edit: Fast ⫸
│ • Status: ❌ Fast effect failed.
╰──────────────────────`);

    let buff = fs.readFileSync('out.mp3');
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(from, {
      audio: buff, mimetype: 'audio/mp4', ptt: true
    }, { quoted: m });

    fs.unlinkSync('out.mp3');
    reply(`
╭─⫷ Voice Edit: Fast ⫸
│ • Status: ✅ Audio sped up.
│ • Effect: 2x speed
╰──────────────────────`);
  });
}
break;
case 'robot': {
  if (!m.quoted || !/audio/.test(m.quoted.mtype)) return reply(`
╭─⫷ Voice Edit: Robot ⫸
│ • Error: No audio found.
│ • Tip: Reply to a voice message.
╰──────────────────────`);

  let media = await m.quoted.download();
  let filename = getRandom('.mp3');
  fs.writeFileSync(filename, media);

  exec(`ffmpeg -i ${filename} -filter_complex "afftfilt=real='hypot(re,im)':imag='0'" out.mp3`, async (err) => {
    fs.unlinkSync(filename);
    if (err) return reply(`
╭─⫷ Voice Edit: Robot ⫸
│ • Status: ❌ Failed to apply robot effect.
╰──────────────────────`);

    let buff = fs.readFileSync('out.mp3');
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(from, {
      audio: buff, mimetype: 'audio/mp4', ptt: true
    }, { quoted: m });

    fs.unlinkSync('out.mp3');
    reply(`
╭─⫷ Voice Edit: Robot ⫸
│ • Status: ✅ Robot effect applied.
│ • Output: Distorted robotic sound
╰──────────────────────`);
  });
}
break;
case 'nightcore': {
  if (!m.quoted || !/audio/.test(m.quoted.mimetype)) return reply(`
╭───⟪ 🌙 Nightcore ⟫───⬣
│ Applies nightcore effect to audio.
╰──────────────⬣`);

  let media = await m.quoted.download();
  let out = getRandom('.mp3');

  ffmpeg(media)
    .audioFilter('asetrate=44100*1.25,atempo=1.1')
    .save(out)
    .on('end', async () => {
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(from, { audio: fs.readFileSync(out), mimetype: 'audio/mp4', ptt: true }, { quoted: m });
      fs.unlinkSync(out);
    });
}
break;
case 'getjid': {
  if (!isOwner) return reply('Only the owner can use this.')

  let target = m.quoted ? m.quoted.sender : m.mentionedJid[0]
  if (!target) return reply('Tag or reply to a user.')

  reply(`👤 JID of user:\n${target}`)
}
break
case 'memory': {
  const used = process.memoryUsage()
  const format = (bytes) => (bytes / 1024 / 1024).toFixed(2) + ' MB'

  let uptime = process.uptime()
  let h = Math.floor(uptime / 3600)
  let m_ = Math.floor((uptime % 3600) / 60)
  let s = Math.floor(uptime % 60)

  reply(`🧠 *Memory Usage:*
• RSS: ${format(used.rss)}
• Heap: ${format(used.heapUsed)} / ${format(used.heapTotal)}

⏱️ *Uptime:* ${h}h ${m_}m ${s}s`)
}
break
case 'restart': {
  if (!isOwner) return reply('Only the owner can restart the bot.')
  reply('♻️ Restarting...')
  process.exit(1)
}
break
case 'getname': {
  if (!isOwner) return reply('Owner only.')
  if (!args[0]) return reply('Usage: #getname 2547xxxxxxx@s.whatsapp.net')

  try {
    let jid = args[0].includes('@') ? args[0] : args[0] + '@s.whatsapp.net'
    let name = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.getName(jid)
    reply(`🔎 Name for ${jid}: ${name}`)
  } catch (e) {
    reply('❌ Failed to fetch name.')
  }
}
break;
case 'speed': {
  const start = new Date().getTime()
  reply('⏱️ Testing speed...').then(() => {
    const end = new Date().getTime()
    reply(`⚡ Speed: ${end - start} ms`)
  })
}
break;
case 'pingall': {
  if (!isOwner || !m.isGroup) return reply('Group + owner only.')
  let text = `👋 *Ping All Members*\n\n`
  let mentions = participants.map(u => u.id)
  text += mentions.map((u, i) => `${i+1}. @${u.split('@')[0]}`).join('\n')
  reply(text, { mentions })
}
break;
case 'masskick': {
  if (!isOwner || !m.isGroup) return reply('Owner only.')
  for (const user of participants) {
    if (user.id !== botNumber && user.id !== m.sender)
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupParticipantsUpdate(m.chat, [user.id], 'remove')
  }
  reply('⚠️ All members have been removed.')
}
break;
case 'lockgroup': {
  if (!isOwner || !m.isGroup) return reply('Owner only.')
  let lock = args[0] === 'on'
  await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupSettingUpdate(m.chat, lock ? 'announcement' : 'not_announcement')
  reply(`🔒 Group is now ${lock ? '*LOCKED*' : '*UNLOCKED*'}`)
}
break;
case 'warn': {
  if (!isOwner || !m.isGroup) return reply('Group + owner only.')
  const target = m.mentionedJid?.[0]
  if (!target) return reply('Mention someone to warn.')

  db.data.warn = db.data.warn || {}
  db.data.warn[target] = (db.data.warn[target] || 0) + 1

  if (db.data.warn[target] >= 3) {
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupParticipantsUpdate(m.chat, [target], 'remove')
    delete db.data.warn[target]
    return reply(`🚫 @${target.split('@')[0]} was kicked (3 warnings)`, { mentions: [target] })
  }

  reply(`⚠️ Warned @${target.split('@')[0]} (${db.data.warn[target]}/3)`, { mentions: [target] })
}
break;
case 'resetwarns': {
  if (!isOwner || !m.isGroup) return reply('Group + owner only.')
  const target = m.mentionedJid?.[0]
  if (!target) return reply('Mention someone.')

  db.data.warn[target] = 0
  reply(`✅ Reset warnings for @${target.split('@')[0]}`, { mentions: [target] })
}
break;
case 'groupaudit': {
  if (!isOwner || !m.isGroup) return reply('Owner only.')
  let log = db.data.auditlog?.[m.chat] || []
  if (!log.length) return reply('📭 No logs yet.')

  let msg = '*📜 Group Audit Logs:*\n\n' + log.slice(-10).reverse().join('\n')
  reply(msg)
}
break;
case 'ping3': {
  const used = process.memoryUsage();
  const chats = Object.entries(𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.chats).filter(([id, data]) => id && data.isChats);
  const groups = Object.entries(𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.chats).filter(([id, data]) => id.endsWith('@g.us'));
  const uptime = process.uptime();
  
  const formatUptime = (s) => {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = Math.floor(s % 60);
    return `${h}h ${m}m ${sec}s`;
  };

  const start = performance.now();
  await reply('Pinging...');
  const end = performance.now();
  const speed = (end - start).toFixed(2);

  const msg = `
┌─[ BOT STATUS ]
│ Memory    : ${(used.rss / 1024 / 1024).toFixed(2)} MB
│ Ping      : ${speed} ms
│ Chats     : ${chats.length}
│ Groups    : ${groups.length}
│ Uptime    : ${formatUptime(uptime)}
│ Platform  : ${process.platform}
│ Node.js   : ${process.version}
└────────────────────
`.trim();

  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { text: msg }, { quoted: m });
}
break;
case 'base64encode': {
  if (!args[0]) return reply('Please provide text to encode.');

  const input = args.join(' ');
  const encoded = Buffer.from(input).toString('base64');

  const msg = `
┌─[ BASE64 ENCODE ]
│ Input   : ${input}
│ Output  : ${encoded}
└────────────────────
`.trim();

  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { text: msg }, { quoted: m });
}
break;
case 'base64decode': {
  if (!args[0]) return reply('Please provide Base64 to decode.');

  try {
    const input = args[0];
    const decoded = Buffer.from(input, 'base64').toString('utf-8');

    const msg = `
┌─[ BASE64 DECODE ]
│ Input   : ${input}
│ Output  : ${decoded}
└────────────────────
`.trim();

    𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { text: msg }, { quoted: m });
  } catch (err) {
    reply('Invalid Base64 string.');
  }
}
break;
case 'uuid': {
  const { v4: uuidv4 } = require('uuid');
  const id = uuidv4();

  const msg = `
┌─[ UUID GEN ]
│ UUID v4 : ${id}
└────────────────────
`.trim();

  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { text: msg }, { quoted: m });
}
break;
case 'screenshot': {
  if (!args[0]) return reply('Please provide a URL to screenshot.');

  const isValidUrl = (url) => {
    try { new URL(url); return true; } catch (_) { return false; }
  };

  if (!isValidUrl(args[0])) return reply('Invalid URL.');

  const shotUrl = `https://image.thum.io/get/fullpage/${args[0]}`;

  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { image: { url: shotUrl }, caption: `🖼 Screenshot of:\n${args[0]}` }, { quoted: m });
}
break;
case 'iplookup': {
  if (!args[0]) return reply('Please provide an IP address to lookup.');

  const fetch = require('node-fetch');
  const ip = args[0];

  try {
    const res = await fetch(`https://ipapi.co/${ip}/json/`);
    const data = await res.json();

    if (data.error) return reply('Invalid IP address.');

    const msg = `
┌─[ IP LOOKUP ]
│ IP       : ${data.ip}
│ City     : ${data.city}
│ Region   : ${data.region}
│ Country  : ${data.country_name}
│ ISP      : ${data.org}
└────────────────────
`.trim();

    𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { text: msg }, { quoted: m });
  } catch (err) {
    reply('Failed to fetch IP info.');
  }
}
break;
case 'timestamp': {
  const now = new Date();
  const msg = `
┌─[ TIMESTAMP ]
│ UNIX : ${Math.floor(now.getTime() / 1000)}
│ ISO  : ${now.toISOString()}
└────────────────────
  `.trim();

  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { text: msg }, { quoted: m });
}
break;
case 'headers': {
  if (!args[0]) return reply('Provide a URL to fetch headers.');

  const fetch = require('node-fetch');

  try {
    const res = await fetch(args[0]);
    const headers = [...res.headers.entries()].map(([k, v]) => `${k}: ${v}`).join('\n');

    𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { text: `┌─[ HEADERS ]\n${headers}` }, { quoted: m });
  } catch {
    reply('Failed to fetch headers.');
  }
}
break;
case 'env': {
  if (!isOwner) return reply('Owner-only command.');

  let envs = Object.keys(process.env).map(k => `${k}=${process.env[k]}`).join('\n');

  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { text: `┌─[ ENV VARS ]\n${envs}` }, { quoted: m });
}
break;
case 'randomport': {
  const port = Math.floor(Math.random() * (9999 - 1024)) + 1024;
  reply(`Generated Port: ${port}`);
}
break;
case 'md5': {
  if (!args[0]) return reply('Enter a string to hash.');

  const crypto = require('crypto');
  const hash = crypto.createHash('md5').update(args.join(' ')).digest('hex');

  const msg = `
┌─[ MD5 HASH ]
│ Input : ${args.join(' ')}
│ Hash  : ${hash}
└────────────────────
  `.trim();

  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { text: msg }, { quoted: m });
}
break;
case 'sha256': {
  if (!args[0]) return reply('Enter a string to hash.');

  const crypto = require('crypto');
  const hash = crypto.createHash('sha256').update(args.join(' ')).digest('hex');

  const msg = `
┌─[ SHA-256 HASH ]
│ Input : ${args.join(' ')}
│ Hash  : ${hash}
└────────────────────
  `.trim();

  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { text: msg }, { quoted: m });
}
break;
case 'baseurl': {
  if (!args[0]) return reply('Provide a URL.');

  try {
    let url = new URL(args[0]);
    reply(`Base Domain: ${url.hostname}`);
  } catch {
    reply('Invalid URL.');
  }
}
break;
case 'pingurl': {
  if (!args[0]) return reply('Provide a URL.');

  const fetch = require('node-fetch');

  try {
    const res = await fetch(args[0]);
    reply(`Status: ${res.status} ${res.statusText}`);
  } catch {
    reply('Site unreachable.');
  }
}
break;
case 'jsbeautify': {
  if (!m.quoted || m.quoted.mtype !== 'extendedTextMessage') return reply('Reply to a JS code block.');

  const beautify = require('js-beautify').js;
  const pretty = beautify(m.quoted.text);

  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { text: pretty }, { quoted: m });
}
break;
case 'eval': {
  if (m.sender !== ownerNumber + '@s.whatsapp.net') return reply('Owner only.');
  try {
    let result = await eval(args.join(' '));
    if (typeof result !== 'string') result = require('util').inspect(result);
    reply(`📥 Eval Result:\n\`\`\`\n${result}\n\`\`\``);
  } catch (e) {
    reply(`❌ Error:\n\`\`\`\n${e}\n\`\`\``);
  }
}
break;
case 'getheaders': {
  if (!args[0]) return reply('Provide a URL.');
  const fetch = require('node-fetch');
  try {
    let res = await fetch(args[0]);
    let headers = JSON.stringify(Object.fromEntries(res.headers), null, 2);
    reply(`📄 Headers:\n\`\`\`json\n${headers}\n\`\`\``);
  } catch {
    reply('Failed to fetch headers.');
  }
}
break;
case 'useragent': {
  reply(m.key?.id ? `User-Agent:\n${m.key.id}` : 'No user-agent info found.');
}
break;
case 'creategc': {
  if (!text) return reply('Enter group name.\nExample: creategc ༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒tech Fans');
  let group = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupCreate(text, [m.sender]);
  reply(`✅ Group created: ${group.gid}`);
  break;
}
case 'createchannel': {
  if (!text) return reply('Enter channel name.\nExample: createchannel 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒 Updates');
  try {
    let channel = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.createNewsletter(text, text, '༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒tech Bot Channel', [m.sender]);
    reply(`✅ Channel created!\nName: ${channel.name}\nID: ${channel.id}`);
  } catch (e) {
    console.log(e);
    reply('❌ Failed to create channel.');
  }
  break;
}

case 'postchannel': {
  if (!isOwner) return reply('Only the owner can post to the channel.');
  const channelJid = '120363351424590490@newsletter'; // your verified channel JID
  if (!text) return reply('Enter message text. Example: postchannel Hello followers!');
  
  try {
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(channelJid, {
      text: `📢 *Channel Update:*\n\n${text}`
    });
    reply('✅ Message posted to the channel.');
  } catch (e) {
    console.error(e);
    reply('❌ Failed to send message to channel.');
  }
}
break;
case 'channeldetails': {
  const jid = text.includes('@newsletter') ? text : `${text}@newsletter`;
  
  try {
    const info = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.getNewsletterMeta(jid);
    reply(`📢 *Channel Info:*\n\nName: ${info.name}\nSubscribers: ${info.subscriberCount}\nID: ${jid}`);
  } catch (e) {
    console.error(e);
    reply('❌ Failed to get channel info.');
  }
}
break;
case 'mychannels': {
  try {
    const channels = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.listNewsletters();
    if (!channels.length) return reply('You have no channels.');

    const list = channels.map(c => `📢 ${c.name}\n🆔 ${c.id}`).join('\n\n');
    reply(`*Your Channels:*\n\n${list}`);
  } catch (e) {
    console.error(e);
    reply('❌ Could not fetch channels.');
  }
}
break;
case 'subscribech': {
  const jid = text.includes('@newsletter') ? text : `${text}@newsletter`
  try {
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.subscribeNewsletter(jid)
    reply(`✅ Subscribed to channel: *${jid}*`)
  } catch (e) {
    console.error(e)
    reply('❌ Failed to subscribe. Make sure the channel ID is correct.')
  }
}
break;
case 'unsubscribech': {
  const jid = text.includes('@newsletter') ? text : `${text}@newsletter`
  try {
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.unsubscribeNewsletter(jid)
    reply(`✅ Unsubscribed from channel: *${jid}*`)
  } catch (e) {
    console.error(e)
    reply('❌ Could not unsubscribe. Check the channel ID.')
  }
}
break;
case 'channeldesc': {
  const channelJid = '120363351424590490@newsletter';
  if (!text) return reply('❌ Provide a new description.');

  try {
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.updateNewsletter(channelJid, {
      description: text
    });
    reply(`✅ Channel description updated.`);
  } catch (e) {
    console.error(e);
    reply('❌ Could not update description.');
  }
}
break;
case 'previewchannel': {
  await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
    text: 'Check out our channel 👇',
    contextInfo: {
      forwardingScore: 999,
      isForwarded: true,
      externalAdReply: {
        title: '༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒tech News',
        body: 'Click to view updates',
        thumbnailUrl: 'https://files.catbox.moe/9liluf.jpg',
        sourceUrl: 'https://whatsapp.com/channel/0029VaFCp8B3NMqA1V4g0l',
        mediaType: 1,
        renderLargerThumbnail: true,
        showAdAttribution: true
      }
    }
  }, { quoted: m });
}
break;
case 'autoread': {
  if (!isOwner) return reply('Only owner can use this command.');
  if (args[0] === 'on') {
    global.autoread = true;
    reply('✅ AutoRead enabled.');
  } else if (args[0] === 'off') {
    global.autoread = false;
    reply('❌ AutoRead disabled.');
  } else {
    reply('Usage: .autoread on/off');
  }
}
break;
case 'autorecordgc': {
  if (!isOwner) return reply('Only owner can use this command.');
  if (args[0] === 'on') {
    global.autorecordgc = true;
    reply('✅ AutoRecord in Groups enabled.');
  } else if (args[0] === 'off') {
    global.autorecordgc = false;
    reply('❌ AutoRecord in Groups disabled.');
  } else {
    reply('Usage: .autorecordgc on/off');
  }
}
break;
case 'autotypinggc': {
  if (!isOwner) return reply('Only owner can use this command.');
  if (args[0] === 'on') {
    global.autotypinggc = true;
    reply('✅ AutoTyping in Groups enabled.');
  } else if (args[0] === 'off') {
    global.autotypinggc = false;
    reply('❌ AutoTyping in Groups disabled.');
  } else {
    reply('Usage: .autotypinggc on/off');
  }
}
break;
case 'autoreadgc': {
  if (!isOwner) return reply('Only owner can use this command.');
  if (args[0] === 'on') {
    global.autoreadgc = true;
    reply('✅ AutoRead in Groups enabled.');
  } else if (args[0] === 'off') {
    global.autoreadgc = false;
    reply('❌ AutoRead in Groups disabled.');
  } else {
    reply('Usage: .autoreadgc on/off');
  }
}
break;
case 'autoreadpm': {
  if (!isOwner) return reply('Only owner can use this command.');
  if (args[0] === 'on') {
    global.autoreadpm = true;
    reply('✅ AutoRead in Private Chats enabled.');
  } else if (args[0] === 'off') {
    global.autoreadpm = false;
    reply('❌ AutoRead in Private Chats disabled.');
  } else {
    reply('Usage: .autoreadpm on/off');
  }
}
break;
case 'detectcall': {
  if (!isOwner) return reply('Only owner can use this command.');
  if (args[0] === 'on') {
    global.detectCall = true;
    reply('📞 Call detection ON. Callers will be blocked.');
  } else if (args[0] === 'off') {
    global.detectCall = false;
    reply('📴 Call detection OFF.');
  } else {
    reply('Usage: .detectcall on/off');
  }
}
break;
case 'autoonline': {
  if (!isOwner) return reply('Only owner can use this command.');
  if (args[0] === 'on') {
    global.autoonline = true;
    reply('🟢 AutoOnline has been turned ON.');
  } else if (args[0] === 'off') {
    global.autoonline = false;
    reply('🔴 AutoOnline has been turned OFF.');
  } else {
    reply('Usage: .autoonline on/off');
  }
}
break;
case 'save': {
  if (!isOwner) return reply('Only owner can use this command.');
  if (!m.quoted) return reply('❌ Reply to a media message or status to save.');

  const quoted = m.quoted;
  const isMedia = quoted.message?.imageMessage || quoted.message?.videoMessage || quoted.message?.documentMessage || quoted.message?.audioMessage;

  if (!isMedia) return reply('❌ Only media messages can be saved.');

  try {
    const buffer = await downloadMediaMessage(
      quoted, 'buffer', {}, { reuploadRequest: sock }
    );

    let ext = 'bin';
    if (quoted.message.imageMessage) ext = 'jpg';
    else if (quoted.message.videoMessage) ext = 'mp4';
    else if (quoted.message.audioMessage) ext = 'mp3';
    else if (quoted.message.documentMessage?.fileName) {
      ext = path.extname(quoted.message.documentMessage.fileName).substring(1);
    }

    const filename = `saved_${Date.now()}.${ext}`;
    const dir = path.join(__dirname, 'saved');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir);

    fs.writeFileSync(path.join(dir, filename), buffer);
    reply(`✅ Media saved as *${filename}*`);

    // 🔁 Optional: Forward to owner
    for (const ownerJid of global.ownerNumber) {
      await sock.sendMessage(ownerJid, {
        [ext === 'jpg' ? 'image' : ext === 'mp4' ? 'video' : ext === 'mp3' ? 'audio' : 'document']: buffer,
        mimetype: quoted.message?.mimetype || undefined,
        caption: `📥 Saved via .save command from @${quoted.sender.split('@')[0]}`,
        fileName: filename,
        mentions: [quoted.sender]
      }, { quoted });
    }

  } catch (err) {
    console.error(err);
    reply('❌ Failed to save media.');
  }
}
break;
case 'autoreact': {
  if (!isOwner) return reply('Only owner can use this command.');
  global.autoReact = !global.autoReact;
  reply(`💬 Auto-react is now *${global.autoReact ? 'ON' : 'OFF'}*.`);
}
break;
case 'autoviewstatus': {
  if (!isOwner) return reply('Only owner can use this command.');
  global.autoViewStatus = !global.autoViewStatus;
  reply(`📷 Auto-view status is now *${global.autoViewStatus ? 'ON' : 'OFF'}*.`);
}
break;
case 'blocklist': {
  if (!isOwner) return reply('Only the owner can use this command.');
  try {
    const blocklist = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.fetchBlocklist();
    if (!blocklist || blocklist.length === 0) return reply('No users are currently blocked.');
    let list = blocklist.map((jid, i) => `${i + 1}. wa.me/${jid.split('@')[0]}`).join('\n');
    reply(`🔒 Blocked Users:\n\n${list}`);
  } catch (err) {
    console.error(err);
    reply('Failed to fetch blocklist.');
  }
}
break;

case 'autoblock': {
  if (!isOwner) return reply('Only the owner can use this command.');
  if (text === 'on') {
    global.autoBlock = true;
    reply('✅ Auto-block enabled.');
  } else if (text === 'off') {
    global.autoBlock = false;
    reply('❌ Auto-block disabled.');
  } else {
    reply('Usage: .autoblock on/off');
  }
}
break;

case 'tempblock': {
  if (!isOwner) return reply('Only the owner can use this command.');
  const [num, mins] = text.split(' ');
  if (!num || !mins) return reply('Usage: .tempblock 254XXXXXXXXX 5');
  const jid = num.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  const duration = parseInt(mins) * 60000;
  try {
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.updateBlockStatus(jid, 'block');
    reply(`⏳ Temporarily blocked ${jid} for ${mins} minutes.`);
    setTimeout(async () => {
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.updateBlockStatus(jid, 'unblock');
      await sock.sendMessage(jid, { text: '⏱️ You have been unblocked.' });
    }, duration);
  } catch (err) {
    console.error(err);
    reply('Failed to temp block.');
  }
}
break;

case 'isblocked': {
  if (!isOwner) return reply('Only the owner can use this command.');
  let jid;
  if (m.quoted) {
    jid = m.quoted.sender;
  } else if (text) {
    const number = text.replace(/[^0-9]/g, '');
    jid = number.includes('@s.whatsapp.net') ? number : number + '@s.whatsapp.net';
  } else {
    return reply('Reply or enter number to check.');
  }
  try {
    const blocklist = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.fetchBlocklist();
    const isBlocked = blocklist.includes(jid);
    reply(isBlocked ? `✅ ${jid} is blocked.` : `❌ ${jid} is not blocked.`);
  } catch (err) {
    console.error(err);
    reply('Error checking block status.');
  }
}
break;

case 'clearblocks': {
  if (!isOwner) return reply('Only the owner can use this command.');
  try {
    const blocklist = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.fetchBlocklist();
    if (!blocklist || blocklist.length === 0) return reply('No users to unblock.');
    for (const jid of blocklist) {
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.updateBlockStatus(jid, 'unblock');
    }
    reply(`✅ All users have been unblocked (${blocklist.length}).`);
  } catch (err) {
    console.error(err);
    reply('Failed to clear block list.');
  }
}
break;
case 'spy': {
  if (!m.mentionedJid[0]) return reply('Tag someone to spy on. Example: .spy @user')
  reply(`🕵️‍♂️ Spying on @${m.mentionedJid[0].split('@')[0]}...\nStatus: Online, Typing...`, null, { mentions: m.mentionedJid })
}
break
case 'creator': {
  reply(`👑 Bot Creator:\nName: ༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒tech\nWhatsApp: wa.me/2348063898506`)
}
break
case 'myname': {
  reply(`🙋 Your name: *${pushname || 'Unknown'}*`)
}
break
case 'package': {
  const status = ['📦 Shipped', '🚚 In Transit', '📍 Out for Delivery', '✅ Delivered']
  reply(`Package Status: *${status[Math.floor(Math.random() * status.length)]}*`)
}
break
case 'motivate': {
  const lines = [
    "Push yourself, because no one else is going to do it for you.",
    "Don’t stop when you’re tired. Stop when you’re done.",
    "You are capable of amazing things."
  ]
  reply(`🚀 Motivation:\n${lines[Math.floor(Math.random() * lines.length)]}`)
}
break
case 'rate': {
  if (!m.mentionedJid[0]) return reply('Tag someone to rate them. Example: .rate @user')
  const rating = Math.floor(Math.random() * 100) + 1
  reply(`🤖 Rating @${m.mentionedJid[0].split('@')[0]}: *${rating}% cool*`, null, { mentions: m.mentionedJid })
}
break
case 'vibe': {
  const vibes = [
    "🌌 Just vibing...",
    "🎧 Lo-fi beats to relax to.",
    "🌿 Peace, love, and code.",
    "☁️ Floating through the day."
  ]
  reply(vibes[Math.floor(Math.random() * vibes.length)])
}
break
case 'randomnumber': {
  const num = Math.floor(Math.random() * 1000) + 1
  reply(`🔢 Your random number is: *${num}*`)
}
break
case 'listdead': {
  if (!m.isGroup) return reply('This command only works in groups.')
  if (!isAdmins && !isOwner) return reply('Only admins can use this command.')

  reply('🔍 Scanning members... (this may take a moment)')

  let groupMetadata = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupMetadata(m.chat)
  let deadUsers = []

  for (let participant of groupMetadata.participants) {
    let userId = participant.id

    try {
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.onWhatsApp(userId).then(res => {
        if (!res || !res[0]?.exists) {
          deadUsers.push(`• @${userId.split('@')[0]}`)
        }
      })
    } catch (e) {
      console.error('[listdead]', userId, e)
      // Assume failed lookup means inactive
      deadUsers.push(`• @${userId.split('@')[0]}`)
    }
  }

  setTimeout(() => {
    if (deadUsers.length === 0) {
      reply('✅ No dead accounts found in this group.')
    } else {
      𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
        text: `💀 *Dead or deleted WhatsApp users in this group:*\n\n${deadUsers.join('\n')}`,
        mentions: deadUsers.map(u => u.replace('• @', '') + '@s.whatsapp.net')
      }, { quoted: m })
    }
  }, 3000)
}
break
case 'kickdead': {
  if (!m.isGroup) return reply('This command can only be used in groups.')
  if (!isAdmins && !isOwner) return reply('Only group admins or the bot owner can use this.')
  if (!isBotAdmins) return reply('I need to be an admin to remove members.')

  reply('🔍 Scanning group members for inactive accounts...')

  let groupMetadata = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupMetadata(m.chat)
  let deadUsers = []

  for (let participant of groupMetadata.participants) {
    let userId = participant.id

    try {
      const exists = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.onWhatsApp(userId)
      if (!exists[0]?.exists) {
        deadUsers.push(userId)
      }
    } catch (e) {
      console.error('[kickdead] Check error:', userId, e)
      deadUsers.push(userId) // assume dead if check fails
    }
  }

  if (deadUsers.length === 0) {
    return reply('✅ No dead accounts found in this group.')
  }

  reply(`💀 Found ${deadUsers.length} dead accounts. Removing...`)

  for (let user of deadUsers) {
    try {
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupParticipantsUpdate(m.chat, [user], 'remove')
    } catch (e) {
      console.error('[kickdead] Removal error:', user, e)
    }
  }

  reply(`✅ Successfully removed ${deadUsers.length} dead accounts.`)
}
break
case 'buyprem': {
  const text = `👑 *Buy Premium Access*

Unlock exclusive features, advanced tools, priority support, and more.

💰 *Price:* $5 per month  
📆 *Duration:* 30 days  
🎁 *Includes:* AI tools, automation, full menus, admin tools

📞 *To purchase premium, message the owner directly:*  
https://wa.me/254785016388?text=Hello%20𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒,%20I%20want%20to%20buy%20Premium

*Thank you for supporting ༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒tech!*
`;

  reply(text);
}
break;
case 'rules': {
  const text = `📜 *Group/Bot Rules*

1. No spamming.
2. Be respectful to others.
3. Do not misuse commands.
4. No NSFW content.
5. Admin decisions are final.

🔒 Violations may lead to warnings or bans.`;
  reply(text);
}
break;
case 'source': {
  reply('🛠 *Bot Source Code:*\nThis bot is private. Contact the owner to learn more:\nhttps://wa.me/254785016388');
}
break;
case 'suggest': {
  const suggestion = q || '';
  if (!suggestion) return reply('Please type your suggestion.\nExample:\n.suggest Add a music search command');

  // Optionally forward to owner
  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage('254785016388@s.whatsapp.net', {
    text: `📥 *New Suggestion:*\nFrom: @${m.sender.split('@')[0]}\n\n${suggestion}`,
    mentions: [m.sender]
  });

  reply('✅ Thank you for your suggestion!');
}
break;
case 'donate': {
  reply(`🙏 *Support The Bot*

You can support us by donating:
📞 mr cross: 23463898506
💬 WhatsApp: wa.me/23463898506
💻 GitHub Sponsor: coming soon

Thanks for the support!`);
}
break;
case 'friends': {
  const friendList = [
    { name: '𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒', role: '👑 Owner', contact: '254785016388' },
    { name: '𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒', role: 'help center', contact: '254704955033' },
    { name: 'Elite', role: '💬 Support', contact: 'hidden' }
  ];

  let caption = '┌──『 👥 *FRIENDS LIST* 』\n';
  for (let friend of friendList) {
    caption += `│\n│ 📛 Name : *${friend.name}*\n│ 🧾 Role : ${friend.role}\n│ 📞 wa.me/${friend.contact}\n`;
  }
  caption += '└───────────────';

  reply(caption);
}
break;
case 'ping2': {
  const start = Date.now();
  const end = Date.now();
  const speed = end - start;
  const botName = 'SLAYQUEEN';
  const status = speed < 200 ? '🟢 FAST' : speed < 600 ? '🟡 AVERAGE' : '🔴 SLOW';

  const caption = `
┌──『 *PING STATUS* 』
│🔧 Bot: ${botName}
│⏱️ Speed: *${speed}ms*
│📶 Status: ${status}
└───────────────
`;

  reply(caption);
}
break;
case 'addfriend': {
  if (!isOwner) return reply('Only the bot owner can add friends.');

  const fs = require('fs');
  const path = './friends.json';

  let input = args.join(' ').split('|').map(i => i.trim());
  if (input.length !== 3) return reply('Usage:\n.addfriend Name | Role | Number');

  const [name, role, contact] = input;
  const newFriend = { name, role, contact };

  // Load existing list or initialize empty
  let friends = [];
  try {
    friends = JSON.parse(fs.readFileSync(path));
  } catch { }

  // Check if already exists
  const exists = friends.some(f => f.contact === contact);
  if (exists) return reply('That contact is already in your friends list.');

  friends.push(newFriend);
  fs.writeFileSync(path, JSON.stringify(friends, null, 2));

  reply(`✅ Friend added:\n\n📛 Name: *${name}*\n🧾 Role: ${role}\n📞 Contact: wa.me/${contact}`);
}
break;
case 'removefriend': {
  if (!isOwner) return reply('Only the bot owner can remove friends.');

  const fs = require('fs');
  const path = './friends.json';

  if (!args[0]) return reply('Usage:\n.removefriend Name or Number');

  let friends = [];
  try {
    friends = JSON.parse(fs.readFileSync(path));
  } catch {
    return reply('No friends list found.');
  }

  const input = args.join(' ').toLowerCase();
  const filtered = friends.filter(f =>
    !(f.name.toLowerCase() === input || f.contact.includes(input))
  );

  if (filtered.length === friends.length) {
    return reply('❌ Friend not found.');
  }

  fs.writeFileSync(path, JSON.stringify(filtered, null, 2));
  reply('✅ Friend removed successfully.');
}
break;
case 'stickerinfo': {
  if (!m.quoted || m.quoted.mtype !== 'stickerMessage') return reply('Reply to a sticker to get its info.')
  let pack = m.quoted.msg.packname || 'N/A'
  let author = m.quoted.msg.author || 'N/A'
  reply(`🎨 Sticker Info:\n• Pack: ${pack}\n• Author: ${author}`)
}
break
case 'ship': {
  if (m.mentionedJid.length < 2) return reply('Tag two users to ship! Example: .ship @user1 @user2')
  let percent = Math.floor(Math.random() * 100) + 1
  reply(`💘 Compatibility: @${m.mentionedJid[0].split('@')[0]} ❤️‍🔥 @${m.mentionedJid[1].split('@')[0]} = *${percent}%*`, null, { mentions: m.mentionedJid })
}
break
case 'color': {
  let color = '#' + Math.floor(Math.random()*16777215).toString(16)
  reply(`🎨 Your random color code: *${color}*`)
}
break
case 'qrcode': {
  if (!q) return reply('Example: .qrcode Hello')
  let url = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(q)}`
  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { image: { url }, caption: `🔍 *QR Code for:* ${q}` }, { quoted: m })
}
break
case 'reminder': {
  if (!q.includes('|')) return reply('Example: .reminder 1m | Drink Water')
  let [time, text] = q.split('|').map(x => x.trim())
  let ms = require('ms')(time)
  if (!ms) return reply('⏱ Invalid time format. Use 1m, 30s, 2h, etc.')
  reply(`✅ Reminder set for *${time}*\n📌 Message: ${text}`)
  setTimeout(() => {
    𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.sender, { text: `⏰ *Reminder:*\n${text}` }, { quoted: m })
  }, ms)
}
break
case '8ball': {
  if (!q.endsWith('?')) return reply('Ask a full question ending with "?"')
  let responses = [
    'Yes', 'No', 'Definitely', 'Ask again later', 'I don’t think so',
    'It is certain', 'Very doubtful', 'Most likely', 'My reply is no'
  ]
  reply(`🎱 ${responses[Math.floor(Math.random() * responses.length)]}`)
}
break
case 'reverse': {
  if (!q) return reply('Example: .reverse Hello')
  reply(q.split('').reverse().join(''))
}
break
case 'status': {
  let uptime = process.uptime()
  let format = (s) => {
    let h = Math.floor(s / 3600)
    let m = Math.floor(s % 3600 / 60)
    let sec = Math.floor(s % 60)
    return `${h}h ${m}m ${sec}s`
  }
  reply(`🤖 *Bot Status:*\nUptime: ${format(uptime)}\nUsers: ${Object.keys(global.db.users || {}).length || 'N/A'}`)
}
break
case 'emoji': {
  if (!q) return reply('Example: .emoji hello')
  let convert = q.toLowerCase().split('').map(c => {
    if (c === ' ') return '  '
    const base = '🇦'.codePointAt(0)
    const offset = c.charCodeAt(0) - 97
    return offset >= 0 && offset < 26 ? String.fromCodePoint(base + offset) : c
  }).join(' ')
  reply(convert)
}
break
case 'vowels': {
  if (!q) return reply('Example: .vowels I love bots')
  let count = (q.match(/[aeiou]/gi) || []).length
  reply(`🅰️ Vowels found: *${count}*`)
}
break
case 'repeat': {
  let [n, ...rest] = q.split(' ')
  if (!n || isNaN(n) || rest.length === 0) return reply('Example: .repeat 3 Hello')
  let text = rest.join(' ')
  reply((text + '\n').repeat(Math.min(10, parseInt(n))))
}
break
case 'broadcast':
case 'bc': {
  if (!isOwner) return reply('Only bot owner can use this command.')
  if (!q) return reply('Please provide a message to broadcast.\nExample: .broadcast Hello everyone!')

  reply('📢 Broadcasting...')

  let chats = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupFetchAllParticipating()
  let groups = Object.entries(chats).map(([id, data]) => id)

  for (let id of groups) {
    await sleep(1000) // Avoid rate limits
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(id, {
      text: `*📢 Broadcast Message:*\n\n${q}`,
      mentions: [m.sender]
    }).catch(e => console.log('Broadcast error:', id, e.message))
  }

  reply(`✅ Broadcast sent to ${groups.length} groups.`)
}
break
case 'listonline': {
  if (!m.isGroup) return reply('Group only.')
  let online = (await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.fetchPresence(m.chat)).lastSeen || {}
  let list = Object.keys(online).map(jid => `@${jid.split('@')[0]}`).join('\n')
  reply(`🟢 *Online Members:*\n${list}`, null, { mentions: participants.map(p => p.id) })
}
break
case 'roast': {
  let roasts = [
    "You're like a cloud. When you disappear, it's a beautiful day.",
    "You're proof even evolution takes a break sometimes.",
    "You're not stupid — you just have bad luck thinking.",
    "You're not ugly, you're just… unique."
  ]
  reply(roasts[Math.floor(Math.random() * roasts.length)])
}
break
case 'food': {
  let foods = ["Pizza 🍕", "Burger 🍔", "Ramen 🍜", "Sushi 🍣", "Fries 🍟", "Pasta 🍝", "Tacos 🌮"]
  reply(`😋 Eat this today: ${foods[Math.floor(Math.random() * foods.length)]}`)
}
break
case 'advice': {
  let tips = [
    "Drink water. Hydration = power.",
    "Never go to bed angry — stay up and plan revenge 😈",
    "Smile at people. It confuses them.",
    "Don't compare your life to others. You're you for a reason."
  ]
  reply(`🧠 *Advice:* ${tips[Math.floor(Math.random() * tips.length)]}`)
}
break
case 'rate': {
  if (!q) return reply('Rate what?\nExample: .rate your bot')
  let rating = Math.floor(Math.random() * 100) + 1
  reply(`🤖 I rate "${q}" a solid *${rating}/100*!`)
}
break
case 'profile': {
  let username = m.pushName || 'User'
  let usernum = m.sender.split('@')[0]
  reply(`👤 *Your Profile:*\n• Name: ${username}\n• Number: ${usernum}\n• Status: Active`)
}
break
case 'myip': {
  let fakeIP = `${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}`
  reply(`🌐 Your IP: ${fakeIP} (jk, not real 😄)`)
}
break
case 'week': {
  const days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]
  let now = new Date()
  reply(`📅 Today is *${days[now.getDay()]}*\nWeek ${Math.ceil(now.getDate()/7)}`)
}
break
case 'hidetag': {
  if (!m.isGroup) return reply('This command can only be used in groups.')
  if (!isAdmins && !isOwner) return reply('Only admins can use this command.')

  let text = q || (m.quoted && m.quoted.text) || '👀'
  let members = participants.map(p => p.id)
  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { text: text, mentions: members }, { quoted: m })
}
break
case 'revoke': {
  if (!m.isGroup) return reply('This command can only be used in groups.')
  if (!isAdmins && !isOwner) return reply('Only admins can use this command.')
  if (!isBotAdmins) return reply('Bot needs to be admin.')

  await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupRevokeInvite(from)
  reply('Group invite link revoked.')
}
break
case 'setname': {
  if (!m.isGroup) return reply('This command can only be used in groups.')
  if (!isAdmins && !isOwner) return reply('Only admins can use this command.')
  if (!q) return reply('Enter new group name.')

  await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupUpdateSubject(from, q)
    .then(() => reply('Group name updated.'))
    .catch(() => reply('Failed to update name.'))
}
break
case 'setdesc': {
  if (!m.isGroup) return reply('This command can only be used in groups.')
  if (!isAdmins && !isOwner) return reply('Only admins can use this command.')
  if (!q) return reply('Enter new group description.')

  await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupUpdateDescription(from, q)
    .then(() => reply('Description updated.'))
    .catch(() => reply('Failed to update description.'))
}
break
case 'info': {
  if (!m.isGroup) return reply('Only in groups.')
  const metadata = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupMetadata(m.chat)
  const infoText = `*Group Info:*\n• Name: ${metadata.subject}\n• ID: ${metadata.id}\n• Members: ${metadata.participants.length}\n• Created: ${new Date(metadata.creation * 1000).toLocaleString()}`
  reply(infoText)
}
break
case 'grouplink': {
  if (!m.isGroup) return reply('Group only.')
  if (!isBotAdmins) return reply('Bot must be admin.')

  let code = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupInviteCode(from)
  reply(`🔗 Group Link:\nhttps://chat.whatsapp.com/${code}`)
}
break
case 'sticker': case 's': {
  if ((m.mimetype || '').includes('image')) {
    let media = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.downloadAndSaveMediaMessage(m)
    let sticker = await writeExifImg(media, { packname: "༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒tech", author: "Bot" })
    𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { sticker: fs.readFileSync(sticker) }, { quoted: m })
    fs.unlinkSync(media)
    fs.unlinkSync(sticker)
  } else if ((m.mimetype || '').includes('video')) {
    if ((m.msg || m).seconds > 11) return reply('🎥 Video too long! Max 10 seconds.')
    let media = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.downloadAndSaveMediaMessage(m)
    let sticker = await writeExifVid(media, { packname: "༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒tech", author: "Bot" })
    𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { sticker: fs.readFileSync(sticker) }, { quoted: m })
    fs.unlinkSync(media)
    fs.unlinkSync(sticker)
  } else {
    reply('📸 Reply to an image or video to make a sticker.')
  }
}
break
case 'tts': {
  if (!q) return reply('Example: .tts en Hello World')
  let [lang, ...text] = q.split(' ')
  let tts = require('google-tts-api')
  let audio = tts.getAudioUrl(text.join(' '), { lang })
  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { audio: { url: audio }, mimetype: 'audio/mp4' }, { quoted: m })
}
break
case 'short': {
  if (!q.startsWith('http')) return reply('Send a valid URL.')
  let res = await fetch(`https://tinyurl.com/api-create.php?url=${q}`).then(res => res.text())
  reply(`🔗 Shortened URL: ${res}`)
}
break
case 'emojimix': {
  if (!q || !q.includes('+')) return reply('Example: .emojimix 😎+🔥')
  let [emoji1, emoji2] = q.split('+')
  let res = await fetch(`https://tenor.googleapis.com/v2/emojis?key=YOUR_TENOR_KEY&query=${emoji1}_${emoji2}`).then(r => r.json())
  if (!res.results?.[0]) return reply('❌ Not found.')
  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { image: { url: res.results[0].url }, caption: `✨ *Emoji Mix*` }, { quoted: m })
}
break
case 'hackertyper': {
  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
    video: { url: 'https://media.tenor.com/1evIYKWB1c8AAAPo/hacker-typing.mp4' },
    caption: `💻 *Hacker Mode Activated!*`,
    mimetype: 'video/mp4'
  }, { quoted: m })
}
break
case "public": {
  if (!isOwner) return reply(mess.owner)
  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.public = true
  reply("✅ Bot is now *Public* !")
}
break
case "private": {
  if (!isOwner) return reply(mess.owner)
  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.public = false
  reply("🔒 Bot is now in *Private Mode*")
}
break
case 'ping': {
  const start = Date.now();
  await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
  react: { text: "🚀", key: m.key }
});
  const latency = Date.now() - start;

  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
    text: `*BOT PINGING:* *${latency}MS*`,
    contextInfo: {
forwardingScore: 2025,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterName: "slayqueen",
newsletterJid: "120363351424590490@newsletter",},      
      externalAdReply: {
        showAdAttribution: true,
        title: `𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒dev`,
        body: `${pushname}, BOT IS ACTIVE: ${runtime(process.uptime())}`,
        thumbnailUrl: 'https://files.catbox.moe/9liluf.jpg',
        sourceUrl: global.link,
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  }, { quoted: m });
  break;
}
 break; 
case "runtime": case 'uptime':
let pinga = `Bot has been active for ${runtime(process.uptime())}`
   𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
                    text: pinga,
                    contextInfo: {
                      forwardingScore: 2025,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterName: "slayqueen",
newsletterJid: "120363287352245413@newsletter",},  
                        externalAdReply: {
                            showAdAttribution: true,
                            title: `𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒dev`,
                            body: `Bot is always active 🥰🥰🥰`,
                            thumbnailUrl: 'https://files.catbox.moe/9liluf.jpg',
                            sourceUrl: 'https://whatsapp.com/channel/0029Vsd3g',
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, { quoted: m });
 break;
 case "sc": case 'script':
 let erepo = `
┏━━━━━━━━━━━━━━━━┓
┃✪︎𝗰𝗵𝗮𝗻𝗻𝗲𝗹
┃ https://t.me/+qrd9y5cmBOM5YTRk
┃
┃✪︎𝗯𝗼𝘁
┃
┃ https://t.me/cross006
┗━━━━━━━━━━━━━━━━┛
`
 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
text: erepo,
contextInfo: {
forwardingScore: 2025,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterName: "slayqueen",
newsletterJid: "120363351424590490@newsletter",},    
externalAdReply: {
showAdAttribution: true,
title: `𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒dev`,
body: `Visit channel for telegram bot link`,
thumbnailUrl: 'https://files.catbox.moe/9liluf.jpg',
sourceUrl: 'https://whatsapp.com/channel/0029VaXBsd3g',
       mediaType: 1,
       renderLargerThumbnail: true
     }
   }
 }, { quoted: m });  
break

case 'clearchat':{
reply('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n')
                    }
break
case 'tagall': case 'tag': {
  if (!m.isGroup) return reply('This command can only be used in groups.')
  if (!isAdmins && !isOwner) return reply('Only admins can use this command.')
  
  let senderName = pushname || m.sender.split('@')[0]
  let teks = `*「 TAG ALL MEMBERS 」*\n`
  
  if (args.length > 0) {
    teks += `\n*Message:* ${args.join(' ')}\n`
  }
  
  teks += `\n*From:* @${m.sender.split('@')[0]}\n\n`
  
  let mentioned = [m.sender]
  for (let mem of participants) {
    teks += `➤ @${mem.id.split('@')[0]}\n`
    mentioned.push(mem.id)
  }
  
  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(from, {
    text: teks,
    mentions: mentioned
  }, { quoted: m })
}
break
case 'gc': {
    if (!m.isGroup) return reply('This command can only be used in groups.')
    if (!isAdmins && !isOwner) return reply('Only admins can use this command.')
    if (!args[0]) return reply('Please type *open* or *close*.')

    if (args[0] === 'open') {
        await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupSettingUpdate(from, 'not_announcement')
        reply('Group has been *opened*. Everyone can now send messages.')
    } else if (args[0] === 'close') {
        await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupSettingUpdate(from, 'announcement')
        reply('Group has been *closed*. Only admins can send messages now.')
    } else {
        reply('Invalid option. Use *open* or *close*.')
    }
}
break
case 'add': {
    if (!m.isGroup) return reply('This command can only be used in groups.')
    if (!isAdmins && !isOwner) return reply('Only admins can use this command.')
    if (!args[0]) return reply('Please provide the number to add.\nExample: *add 234XXXXXXXXXX*')

    let number = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'

    // Check if number is valid length
    if (number.length < 12) return reply('Invalid number. Please use full international format.')

    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupParticipantsUpdate(from, [number], 'add')
        .then(() => reply(`User @${number.split('@')[0]} has been added.`))
        .catch(() => reply('Failed to add user. They may have left recently or have group privacy settings.'))
}
break
case 'kick': {
  if (!m.isGroup) return reply(`╭─❖\n│  🚫 *Group Only*\n╰──⭔ This command can only be used in groups.`);
  if (!isAdmins && !isOwner) return reply(`╭─❖\n│  ⚠️ *Permission Denied*\n╰──⭔ Only *admins* or *owner* can use this command.`);
  if (!m.quoted && !args[0]) return reply(`╭─❖\n│  🔖 *Usage*\n╰──⭔ Tag or reply to the user you want to *kick*.`);

  let user;
  if (m.quoted) {
    user = m.quoted.sender;
  } else {
    user = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  }

  if (!participants.some(p => p.id === user)) return reply(`╭─❖\n│  ❌ *User Not Found*\n╰──⭔ That user is *not in this group*.`);
  if (user === botNumber) return reply(`╭─❖\n│  🤖 *Bot Restriction*\n╰──⭔ I cannot kick *myself*.`);
  if (user === m.sender) return reply(`╭─❖\n│  🪞 *Self Kick Blocked*\n╰──⭔ You cannot kick *yourself*.`);

  await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupParticipantsUpdate(from, [user], 'remove')
    .then(() => reply(`╭─❖\n│  ✅ *Kick Success*\n│  👤 User: @${user.split('@')[0]}\n╰──⭔ Has been *removed* from the group.`))
    .catch(() => reply(`╭─❖\n│  ❌ *Kick Failed*\n╰──⭔ Could not remove user.`));
}
break;
case 'promote': {
    if (!m.isGroup) return reply('This command can only be used in groups.')
    if (!isAdmins && !isOwner) return reply('Only admins can use this command.')
    if (!m.quoted && !args[0]) return reply('Tag or reply to a user to promote.')

    let user;
    if (m.quoted) {
        user = m.quoted.sender;
    } else {
        user = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    }

    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupParticipantsUpdate(from, [user], 'promote')
        .then(() => reply(`@${user.split('@')[0]} is now an admin.`))
        .catch(() => reply('Failed to promote user.'));
}
break;
case 'demote': {
    if (!m.isGroup) return reply('This command can only be used in groups.')
    if (!isAdmins && !isOwner) return reply('Only admins can use this command.')
    if (!m.quoted && !args[0]) return reply('Tag or reply to a user to demote.')

    let user;
    if (m.quoted) {
        user = m.quoted.sender;
    } else {
        user = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    }

    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupParticipantsUpdate(from, [user], 'demote')
        .then(() => reply(`@${user.split('@')[0]} is no longer an admin.`))
        .catch(() => reply('Failed to demote user.'));
}
break;
case 'invite': {
  if (!m.isGroup) return reply('This command can only be used in groups.');
  if (!isAdmins && !isOwner) return reply('Only admins can use this command.');
  
  let code = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupInviteCode(from);
  let groupLink = `https://chat.whatsapp.com/${code}`;
  
  reply(`*Group Invite Link:*\n${groupLink}`);
}
break;
case 'del': case 'delete': {
  if (!m.quoted) return reply('Please reply to the message you want to delete.');
  
  // Group check
  if (m.isGroup) {
    if (!isAdmins && !isOwner) return reply('Only admins or owner can use this command in groups.');
  }
  
  let msgToDelete = m.quoted;
  
  try {
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(msgToDelete.chat, {
      delete: {
        remoteJid: msgToDelete.chat,
        fromMe: msgToDelete.fromMe,
        id: msgToDelete.id,
        participant: msgToDelete.sender
      }
    });
  } catch (err) {
    console.log('Delete Error:', err);
    reply('Failed to delete the message.');
  }
}
break
case 'savecontact': case 'svcontact': case 'vcf': {
  try {
    // Basic validations
    if (!m.isGroup) {
      return reply('This command is made for group');
    }
    
    if (!(isAdmins || isCreator)) {
      return reply('Admin privileges required!');
    }
    
    if (!isBotAdmins) {
      return reply('Bot need to be admin');
    }
    
    const group = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.groupMetadata(m.chat).catch(err => {
      console.error('[VCF] Group metadata error:', err);
      throw new Error('GROUP_METADATA_FAILURE');
    });
    
    const vcfEntries = group.participants.map((user, index) => {
      try {
        const num = user.id.replace(/@.+/, '');
        return `BEGIN:VCARD
VERSION:3.0
FN:${group.subject} Member ${index + 1}
TEL;TYPE=CELL:+${num}
END:VCARD`;
      } catch (e) {
        console.error('[VCF] Error processing user', user.id, e);
        return null;
      }
    }).filter(entry => entry !== null);
    
    const tempPath = './contacts.vcf';
    try {
      require('fs').writeFileSync(tempPath, vcfEntries.join('\n'));
    } catch (e) {
      console.error('[VCF] File write error:', e);
      return reply('📂 File creation failed!');
    }
    
    const asciiCaption = `
*Group:* ${(group.subject || 'Unknown').substring(0,20).padEnd(20)}
*Contacts:* ${group.participants.length.toString().padStart(3).padEnd(23)}`.trim();
    
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
      document: { url: tempPath },
      fileName: `${group.subject}_contacts.vcf`,
      mimetype: 'text/vcard',
      caption: asciiCaption,
      contextInfo: {
        externalAdReply: {
          title: 'GROUP CONTACTS',
          body: 'Generated by slayqueen',
          thumbnailUrl: 'https://files.catbox.moe/9liluf.jpg',
          mediaType: 1
        }
      }
    }, { quoted: m }).catch(e => {
      console.error('[VCF] Message send error:', e);
      throw new Error('MESSAGE_SEND_FAILURE');
    });
    
    try {
      require('fs').unlinkSync(tempPath);
    } catch (e) {
      console.error('[VCF] File cleanup error:', e);
    }
    
  } catch (error) {
    console.error('[VCF] Master Error:', error.stack);
    reply(`❌ Failed: ${error.message}`).catch(e =>
      console.error('[VCF] Even error reply failed:', e));
  }
  break;
}
break
case 'tagadmin': {
  if (!m.isGroup) return reply('This command can only be used in group chats.')
  if (!isAdmins && !isOwner) return reply('Only group admins or the bot owner can use this command.')
  let textTag = args.join(" ") || 'Attention admins!'
  let teks = `*${textTag}*\n\n`
  for (let admin of groupAdmins) {
    teks += `@${admin.split('@')[0]} `
  }
  await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
    text: teks.trim(),
    mentions: groupAdmins
  }, { quoted: m })
}
break
case 'totag': {
  if (!m.isGroup) return reply('This command can only be used in groups.')
  if (!isAdmins && !isOwner) return reply('You must be an admin to use this command.')
  
  const mem = participants.map(u => u.id)
  const quoted = m.quoted
  const mime = (quoted?.msg || quoted)?.mimetype || ''
  
  if (quoted && /image|video|audio|document/.test(mime)) {
    let media = await quoted.download()
    let type = mime.split('/')[0]
    
    let options = {
      mentions: mem,
      quoted: m
    }
    
    if (type === 'image') {
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { image: media, caption: q ? q : '', ...options })
    } else if (type === 'video') {
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { video: media, caption: q ? q : '', ...options })
    } else if (type === 'audio') {
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { audio: media, mimetype: 'audio/mp4', ...options })
    } else {
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { document: media, mimetype: mime, fileName: 'file', ...options })
    }
    
  } else if (quoted && quoted.text) {
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
      text: quoted.text,
      mentions: mem
    }, { quoted: m })
    
  } else if (q) {
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
      text: q,
      mentions: mem
    }, { quoted: m })
    
  } else {
    reply('Reply to a message or provide text.\nExample:\n.totag Hello everyone!')
  }
}
break
case 'song': {
  if (!text) return reply(`*Example*: ${prefix + command} Faded by lord 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒`);
  
  try {
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { react: { text: `🎵`, key: m.key } });
    
    const yts = require('yt-search');
    const search = await yts(text);
    const video = search.videos[0];
    
    if (!video) return reply(`*No results found for:* ${text}`);
    
    const thumbnailUrl = video.thumbnail;
    const videoUrl = video.url;
    
    const body = `╭━━━━━━━━━\n` +
      `┃ *slayqueen downloader*\n\n` +
      `> *ᴛɪᴛʟᴇ:* ${video.title}\n\n` +
      `┃ *ᴠɪᴇᴡꜱ:* ${video.views}\n` +
      `┃ *ᴅᴜʀᴀᴛɪᴏɴ:* ${video.timestamp}\n` +
      `┃ *ᴜᴘʟᴏᴀᴅᴇᴅ:* ${video.ago}\n\n` +
      `> *ᴜʀʟ:* ${videoUrl}\n\n` +
      `┃ *Enjoy your music®*\n` +
      `╰━━━━━━━━━━━━━━━━━━┈⊷\n` +
      `> *©𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒*`;
    
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
      image: { url: thumbnailUrl },
      caption: body
    }, { quoted: m });
    
    let success = false;
    let download_url, title;
    
    // Try first API
    try {
      const res1 = await axios.get(`https://apis.davidcyriltech.my.id/download/ytmp3?url=${encodeURIComponent(videoUrl)}`);
      if (res1?.data?.success) {
        download_url = res1.data.result.download_url;
        title = res1.data.result.title;
        success = true;
      }
    } catch (e) {
      console.warn('Primary API failed:', e.message);
    }
    
    // Fallback if needed
    if (!success) {
      try {
        const res2 = await axios.get(`https://api.giftedtech.web.id/api/download/ytmp3?apikey=gifted&url=${encodeURIComponent(videoUrl)}`);
        if (res2?.data?.success) {
          download_url = res2.data.result.download_url;
          title = res2.data.result.title;
          success = true;
        }
      } catch (e) {
        console.warn('Fallback API failed:', e.message);
      }
    }
    
    // Send audio as document
    if (success) {
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
        document: { url: download_url },
        mimetype: 'audio/mpeg',
        fileName: `${title}.mp3`,
        caption: `🎧 *Here's your track:*\n> *𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒tech to the world*`,
        contextInfo: {
          externalAdReply: {
            title: `${title}`,
            body: `🎵 High Quality • slayqueen`,
            thumbnailUrl: thumbnailUrl,
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: m });
    } else {
      reply(`*❌ Failed to fetch the song from both sources. Please try again later.*`);
    }
    
  } catch (error) {
    console.error('Error during /play2 command:', error);
    reply(`_*An error occurred while downloading*_ > Please try again later.`);
  }
  
  break;
}
case 'img': case 'anime': case 'image': {
  if (!text) return reply(`*Example*: ${prefix + command} Anime`);
  
  try {
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { react: { text: `🎨`, key: m.key } });
    
    const apiUrlForImages = `https://img.hazex.workers.dev/?prompt=${encodeURIComponent(text)}`;
    
    // Generate and send 5 images
    const footer = "\n> *𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒 dev©*";
    for (let i = 0; i < 5; i++) {
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
        image: { url: apiUrlForImages }, // URL is already constructed
        caption: footer
      }, { quoted: m });
    }
    
  } catch (error) {
    console.error('Error fetching images:', error);
    reply(`*An error occurred while fetching images. Please try again later.*`);
  }
  break;
}
case 'play':
case 'ytmp3': {
  if (!text) return reply(`*Example*: ${prefix + command} Faded by lord 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒`);
  
  try {
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { react: { text: `🎵`, key: m.key } });
    
    const yts = require('yt-search');
    const search = await yts(text);
    const video = search.videos[0];
    
    if (!video) return reply(`*No results found for:* ${text}`);
    
    const thumbnailUrl = video.thumbnail;
    const videoUrl = video.url;
    
    const info = `╭━━━━━━━━━\n` +
      `┃ *SLAYQUEEN PLAYER*\n\n` +
      `> *ᴛɪᴛʟᴇ:* ${video.title}\n\n` +
      `┃ *ᴠɪᴇᴡꜱ:* ${video.views}\n` +
      `┃ *ᴅᴜʀᴀᴛɪᴏɴ:* ${video.timestamp}\n` +
      `┃ *ᴜᴘʟᴏᴀᴅᴇᴅ:* ${video.ago}\n\n` +
      `> *ᴜʀʟ:* ${videoUrl}\n\n` +
      `┃ *Enjoy your music®*\n` +
      `╰━━━━━━━━━━━━━━━━━━┈⊷\n` +
      `> *𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒dev*`;
    
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
      image: { url: thumbnailUrl },
      caption: info
    }, { quoted: m });
    
    // === Try nexoracle.com first ===
    let download_url = null;
    let title = null;
    let quality = null;
    let success = false;
    
    try {
      const res1 = await axios.get(`https://api.nexoracle.com/downloader/yt-audio2?apikey=bde27483eae0f54a6e&url=${encodeURIComponent(videoUrl)}`);
      if (res1?.data?.status === 200 && res1?.data?.result?.audio) {
        download_url = res1.data.result.audio;
        title = res1.data.result.title;
        quality = res1.data.result.quality || 'HQ';
        success = true;
      }
    } catch (e) {
      console.warn("NexOracle API failed:", e.message);
    }
    
    // === Fallback: davidcyriltech.my.id ===
    if (!success) {
      try {
        const res2 = await axios.get(`https://apis.davidcyriltech.my.id/download/ytmp3?url=${encodeURIComponent(videoUrl)}`);
        if (res2?.data?.success) {
          download_url = res2.data.result.download_url;
          title = res2.data.result.title;
          quality = 'HQ';
          success = true;
        }
      } catch (e) {
        console.warn("DavidCyril API failed:", e.message);
      }
    }
    
    // === Final Fallback: giftedtech ===
    if (!success) {
      try {
        const res3 = await axios.get(`https://api.giftedtech.web.id/api/download/ytmp3?apikey=gifted&url=${encodeURIComponent(videoUrl)}`);
        if (res3?.data?.success) {
          download_url = res3.data.result.download_url;
          title = res3.data.result.title;
          quality = 'HQ';
          success = true;
        }
      } catch (e) {
        console.warn("GiftedTech API failed:", e.message);
      }
    }
    
    // === Send audio or failure ===
    if (success) {
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
        audio: { url: download_url },
        mimetype: 'audio/mpeg',
        fileName: `${title}.mp3`,
        contextInfo: {
          externalAdReply: {
            title: title,
            body: `🎵 ${quality} • 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒dev`,
            thumbnailUrl: thumbnailUrl,
            mediaType: 1,
            renderLargerThumbnail: true,
            showAdAttribution: true,
            sourceUrl: videoUrl
          }
        }
      }, { quoted: m });
    } else {
      reply(`*❌ All 3 sources failed. Please try again later.*`);
    }
    
  } catch (error) {
    console.error('Error during /play command:', error);
    reply(`_*An error occurred while downloading*_ > Please try again later.`);
  }
  
  break;
}

    
case 'yts': case 'ytsearch': {
  if (!text) return reply(`Example : ${prefix + command} Alan walker alone`)
  let yts = require("yt-search")
  let search = await yts(text)
  let teks = '*YOUTUBE SEARCH*\n\nSEARCH: ' + text + '\n\n'
  let no = 1
  for (let i of search.all) {
    teks += `*NO:* ${no++}\n*Type:* ${i.type}\n*Video ID:* ${i.videoId}\n*Title:* ${i.title}\n*Views:* ${i.views}\n*Duration:* ${i.timestamp}\n*Uploaded:* ${i.ago}\n\n*Url:* ${i.url}\n\n`
  }
  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { image: { url: search.all[0].thumbnail }, caption: teks }, { quoted: m })
}
break

case 'ssweb': {
  if (!args[0]) return reply(`Please provide a link\n\n Example: ${prefix + command}.`);
  await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m?.chat, { react: { text: `📸`, key: m?.key } });
  
  let apiUrl = `https://apis.davidcyriltech.my.id/ssweb?url=${encodeURIComponent(args[0])}`;
  
  try {
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { image: { url: apiUrl }, caption: `🖼️ Screenshot of ${args[0]}` }, { quoted: m });
  } catch (error) {
    console.error(error);
    reply('Failed to capture the screenshot. Please try again later.');
  }
  break;
}
break
case 'block': {
  if (!isOwner) return reply('Only the owner can use this command.');
  
  let target;
  if (m.quoted) {
    target = m.quoted.sender;
  } else if (text) {
    const number = text.replace(/[^0-9]/g, '');
    target = number.includes('@s.whatsapp.net') ? number : number + '@s.whatsapp.net';
  } else if (!m.isGroup) {
    target = m.chat;
  } else {
    return reply('Reply to a message, type a number, or use this in a private chat.');
  }
  
  try {
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.updateBlockStatus(target, "block");
    reply(`Successfully blocked ${target}`);
  } catch (err) {
    console.error(err);
    reply('Failed to block the user.');
  }
}
break;
case 'unblock': {
  if (!isOwner) return reply('Only the owner can use this command.');
  
  let target;
  if (m.quoted) {
    target = m.quoted.sender;
  } else if (text) {
    const number = text.replace(/[^0-9]/g, '');
    target = number.includes('@s.whatsapp.net') ? number : number + '@s.whatsapp.net';
  } else if (!m.isGroup) {
    target = m.chat;
  } else {
    return reply('Reply to a message, type a number, or use this in a private chat.');
  }
  
  try {
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.updateBlockStatus(target, "unblock");
    reply(`Successfully unblocked ${target}`);
  } catch (err) {
    console.error(err);
    reply('Failed to unblock the user.');
  }
}
break;
//Facebook Ig tiktok
case 'tiktok':
case 'facebook':
case 'aio':
case 'instagram': {
  if (!text) return reply(`Give Me A Video Link \n\n*Example:* ${prefix + command} https://www.facebook.com/reel/123456`);
  await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { react: { text: `📥`, key: m?.key } });
  
  try {
    
    
    const apiUrl = `https://apis.davidcyriltech.my.id/download/aio?url=${encodeURIComponent(text)}`;
    const response = await axios.get(apiUrl);
    
    if (response.data.success) {
      const { title, low_quality, high_quality } = response.data.video;
      
      const isDirectDownloadHD = high_quality.includes("tinyurl");
      const isDirectDownloadSD = low_quality.includes("tinyurl");
      
      if (isDirectDownloadHD || isDirectDownloadSD) {
        if (isDirectDownloadHD) {
          await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
            video: { url: high_quality },
            mimetype: 'video/mp4',
            fileName: `${title}_HD.mp4`,
            caption: `🎥 *Title:* ${title}\n*Quality:* HD\n> *slayqueen*`
          }, { quoted: m });
        }
        if (isDirectDownloadSD) {
          await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
            video: { url: low_quality },
            mimetype: 'video/mp4',
            fileName: `${title}_SD.mp4`,
            caption: `🎥 *Title:* ${title}\n*Quality:* SD\n> *slayqueen*`
          }, { quoted: m });
        }
      } else {
        await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { react: { text: `📥`, key: m?.key } });
        
        
        const hdBuffer = await axios.get(high_quality, { responseType: 'arraybuffer' });
        const sdBuffer = await axios.get(low_quality, { responseType: 'arraybuffer' });
        
        if (high_quality) {
          await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
            video: Buffer.from(hdBuffer.data),
            mimetype: 'video/mp4',
            fileName: `${title}_HD.mp4`,
            caption: `🎥 *Title:* ${title}\n*Quality:* HD\n> *slayqueen*`
          }, { quoted: m });
        }
        if (low_quality) {
          await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
            video: Buffer.from(sdBuffer.data),
            mimetype: 'video/mp4',
            fileName: `${title}_SD.mp4`,
            caption: `🎥 *Title:* ${title}\n*Quality:* SD\n> *slayqueen*`
          }, { quoted: m });
        }
      }
    } else {
      reply("❌ Unable to fetch the video. Please check the URL and try again.");
    }
  } catch (error) {
    console.error('Error in AIO Downloader:', error.message);
    reply("❌ An error occurred while processing your request. Please try again later.");
  }
  break;
}
break
case 'quotes':
const quoteelitey = await axios.get(`https://favqs.com/api/qotd`)
const textquotes = `*Quote:* ${quoteelitey.data.quote.body}\n\n*Author:* ${quoteelitey.data.quote.author}`
return reply(textquotes)

break
case 'fact': {
  const { data } = await axios.get(`https://nekos.life/api/v2/fact`)
  return reply(`*Fact:* ${data.fact}\n`)
}
break
case "spotify-search": case "sps": {
  if (!text) return reply("Please enter a search keyword");
  
  const url = `https://spotifyapi.caliphdev.com/api/search/tracks?q=${encodeURIComponent(text)}`;
  
  fetch(url)
  .then(response => response.json())
  .then(async data => {
    if (data.length == 0) return reply("No results found.");
    
    let textOutput = '\n*SPOTIFY SEARCH*\n*🔎 Search Results*\n\n';
    for (let i of data) {
      textOutput += `*◦ Title:* ${i.title}
  *◦ Artist:* ${i.artist || "unknown"}
  *◦ Album:* ${i.album || "unknown"}
  *◦ Duration:* ${i.duration || "unknown"}
  *◦ Link:* ${i.url}\n\n`;
    }
    reply(textOutput);
  })
  .catch(err => reply("An error occurred: " + err.toString()));
}
break
case "spoty-download": case "spotifydl": case "spdl": {
  
  if (!text) return reply('where is the link??');
  // Mengambil URL dari API download
  let apiURL = `https://spotifyapi.caliphdev.com/api/download/track?url=${encodeURIComponent(text)}`;
  
  try {
    // Mendapatkan data dari API
    let response = await fetch(apiURL);
    
    // Memastikan respon adalah tipe audio
    if (response.headers.get("content-type") === "audio/mpeg") {
      // Mengirim audio melalui WhatsApp
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { audio: { url: apiURL }, mimetype: 'audio/mpeg' }, { quoted: m });
    } else {
      reply("An error occur, use .splay");
    }
  } catch (error) {
    console.error(error);
    reply("An error occur while downloading audio file");
  }
}
break
case "splay": {
  const axios = require("axios");
  if (!text) return reply('Provide spotify url or text');
  
  try {
    // URL API untuk pencarian lagu
    const searchApiUrl = `https://spotifyapi.caliphdev.com/api/search/tracks?q=${encodeURIComponent(text)}`;
    const searchData = (await axios.get(searchApiUrl)).data;
    
    // Pilih hasil pertama dari data pencarian
    const data = searchData[0];
    if (!data) return reply("please just keep calm");
    
    // Teks yang akan dikirimkan
    const tekswait = `╭━━━━━━━━━
┃ *SPOTIFY MUSIC - DOWNLOADER*

> *ᴛɪᴛʟᴇ:* ${data.title}

┃ *ᴀʀᴛɪꜱᴛ* ${data.artist}

> *ᴜʀʟ:* ${data.url}

┃ *Enjoy your music®*
╰━━━━━━━━━━━━━━━━━━┈⊷
> *slayqueen*`;
    
    // Mengirim pesan informasi lagu
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, {
      text: `${tekswait}`,
      contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          showAdAttribution: true,
          title: `${data.title}`,
          body: "SPOTIFY SEARCH & DOWNLOAD",
          thumbnailUrl: data.thumbnail,
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });
    
    // URL API untuk download lagu
    const downloadApiUrl = `https://spotifyapi.caliphdev.com/api/download/track?url=${encodeURIComponent(data.url)}`;
    // Mendapatkan data dari API
    let response = await fetch(downloadApiUrl);
    
    // Memastikan respon adalah tipe audio
    if (response.headers.get("content-type") === "audio/mpeg") {
      // Mengirim audio melalui WhatsApp
      await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { audio: { url: downloadApiUrl }, mimetype: 'audio/mpeg' }, { quoted: m });
    } else {
      reply("lol, its your music or not??");
    }
  } catch (error) {
    console.error(error);
    reply("failed to download youre audio");
  }
}
break
case 'truth': {
  try {
    const apiUrl = 'https://apis.davidcyriltech.my.id/truth';
    const imagePath = 'https://i.ibb.co/gLNc5SGK/ce5871f200bb421678c982f5af52d7fd.jpg'; // 
    const userTag = `@${m.sender.split('@')[0]}`;
    
    
    const response = await axios.get(apiUrl);
    
    if (response.data.status === 200 && response.data.success) {
      const truthQuestion = response.data.question;
      
      
      𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(from, {
        image: { url: imagePath },
        caption: `${userTag}, you chose *TRUTH*!\n\n*Question:* ${truthQuestion}\n> *slayqueen*`,
        mentions: [m.sender],
      }, { quoted: m });
    } else {
      
      reply('Failed to fetch a truth question. Please try again later.');
    }
  } catch (error) {
    
    if (error.response) {
      reply(`API Error: ${error.response.data.message || 'Unknown API error.'}`);
    } else if (error.request) {
      reply('No response received from the API. Please try again later.');
    } else {
      reply(`An error occurred: ${error.message}`);
    }
  }
  break;
}
break
case 'ai': {
  if (!text) return reply(`Hello what should i help you?`)
async function openai(text, logic) { // Membuat fungsi openai untuk dipanggil
    let response = await axios.post("https://chateverywhere.app/api/chat/", {
        "model": {
            "id": "gpt-4",
            "name": "GPT-4",
            "maxLength": 32000,  // Sesuaikan token limit jika diperlukan
            "tokenLimit": 8000,  // Sesuaikan token limit untuk model GPT-4
            "completionTokenLimit": 5000,  // Sesuaikan jika diperlukan
            "deploymentName": "gpt-4"
        },
        "messages": [
            {
                "pluginId": null,
                "content": text, 
                "role": "user"
            }
        ],
        "prompt": logic, 
        "temperature": 0.5
    }, { 
        headers: {
            "Accept": "/*/",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
    });
    
    let result = response.data;
    return result;
}

let kanjuthann = await openai(text, "I am an artificial intelligence")
reply(kanjuthann)
}
break
case 'mediafire': {
      if (!text) return reply(`*Example*: ${prefix + command} https://www.mediafire.com/file/rmpx6iv7kiboki3/ELITEPRO-master+(2).zip/file`);
      
      try {
          
          await EliteProEmpire.sendMessage(m.chat, { react: { text: `📥`, key: m?.key } });
          
          
          const apiUrl = `https://apis.davidcyriltech.my.id/mediafire?url=${encodeURIComponent(text)}`;
          const apiResponse = await axios.get(apiUrl);
          
          
          if (apiResponse.data && apiResponse.data.downloadLink) {
              const { fileName, mimeType, downloadLink } = apiResponse.data;
              
              
              await EliteProEmpire.sendMessage(m.chat, {
                  document: { url: downloadLink },
                  mimetype: mimeType,
                  fileName: fileName,
                  caption: `📦 *File Name:* ${fileName}\n> *slayqueen*`
              }, { quoted: m });
          } else {
              
              reply(`*Failed to fetch file details! Please check the MediaFire URL and try again.*`);
          }
      } catch (error) {
          
          console.error('Error during MediaFire command:', error);
          reply(`*An error occurred while processing your request. Please try again later.*`);
      }
      break;
  }
break
case 'tiny': {
  try {
    if (!text) {
      return reply(`Please provide a URL to shorten.\n*Usage:*\n.tiny https://example.com`);
    }
    
    const urlToShorten = text.trim();
    
    if (!urlToShorten) {
      return reply('Please provide a valid URL to shorten.');
    }
    
    // Construct the API URL for TinyURL
    const apiUrl = `https://tinyurl.com/api-create.php?url=${encodeURIComponent(urlToShorten)}`;
    
    // Fetch the shortened URL
    const response = await axios.get(apiUrl);
    
    console.log('API Response:', response.data);
    
    // Send the shortened URL as a message
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(from, {
      text: `Here is your shortened URL: ${response.data}`,
    }, { quoted: m });
    
  } catch (error) {
    console.error('Error shortening URL:', error.message);
    await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(from, {
      text: 'Error shortening URL. Please check the URL format or try again later.',
    }, { quoted: m });
  }
  break;
}
break
case 'getpp': {
  let target;
  
  // If it's a reply to someone in a group or private chat
  if (m.message?.extendedTextMessage?.contextInfo?.participant) {
    target = m.message.extendedTextMessage.contextInfo.participant;
  }
  // If in a private chat, get the other person's profile picture
  else if (!m.isGroup) {
    target = m.chat;
  }
  // If user mentions someone, get their profile picture
  else if (m.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
    target = m.message.extendedTextMessage.contextInfo.mentionedJid[0];
  }
  // If user provides a number (for private chat)
  else if (args[0]) {
    target = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  }
  // Otherwise, get sender's own profile picture
  else {
    target = m.sender;
  }
  
  let username = target.split('@')[0];
  let profileCaption = `*@${username} profile picture*`;
  
  try {
    ppuser = await 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.profilePictureUrl(target, 'image');
  } catch (err) {
    ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60';
  }
  
  ppelite = await getBuffer(ppuser);
  
  𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(from, {
    image: ppelite,
    caption: profileCaption,
    mentions: [target]
  }, { quoted: m });
}
break
case 'gitclone':
if (!args[0]) return reply(`*Usage:* ${prefix}${command} https://github.com/EliteProTech/ELITE-PRO-V1`)
if (!isUrl(args[0]) && !args[0].includes('github.com')) return reply(`Link invalid!!`)
let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
let [, user, repo] = args[0].match(regex1) || []
repo = repo.replace(/.git$/, '')
let url = `https://api.github.com/repos/${user}/${repo}/zipball`
let filename = (await fetch(url, { method: 'HEAD' })).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒.sendMessage(m.chat, { document: { url: url }, fileName: filename + '.zip', mimetype: 'application/zip' }, { quoted: m }).catch((err) => reply(mess.error))
break
            case 'pickupline': {
              try {
                let res = await fetch(`https://api.popcat.xyz/pickuplines`)
                if (!res.ok) {
                  throw new Error(`API request failed with status ${res.status}`)
                }
                let json = await res.json()
                let pickupLine = `*Here's a pickup line for you:*\n\n${json.pickupline}`
                reply(pickupLine)
              } catch (error) {
                console.error(error)
                // Handle the error appropriately
              }
            }
break
case 'autorecord': {
  if (!isOwner) return reply(mess.owner);
  if (!q) return reply(`Example:\n${prefix + command} on / off`);
  
  if (q === 'on') {
    global.autoRecording = true;
    reply('✅ Auto-recording has been *enabled*.');
  } else if (q === 'off') {
    global.autoRecording = false;
    reply('❌ Auto-recording has been *disabled*.');
  } else {
    reply(`Invalid option. Use *on* or *off*`);
  }
}
break
case 'autotyping': {
  if (!isOwner) return reply(mess.owner);
  if (!q) return reply(`Example: ${prefix + command} on / off`);
  
  if (q === 'on') {
    global.autoTyping = true;
    reply('✅ Auto-typing has been *enabled*.');
  } else if (q === 'off') {
    global.autoTyping = false;
    reply('❌ Auto-typing has been *disabled*.');
  } else {
    reply(`Invalid option. Use *on* or *off*`);
  }
}
break;
                
            default:
			if (body.startsWith("<")) {
                if (!isOwner) return;
                try {
                    const output = await eval(`(async () => ${q})()`);
                    await m.reply(`${typeof output === 'string' ? output : JSON.stringify(output, null, 4)}`);
                } catch (e) {
                    await m.reply(`Error: ${String(e)}`);
                }
            }
			if (budy.startsWith(">")) {
			if (!isOwner) return
				try {
					let evaled = await eval(q);
					if (typeof evaled !== "string") evaled = util.inspect(evaled);
					await m.reply(evaled);
				} catch (e) {
					await m.reply(`Error: ${String(e)}`);
				}
			}
			if (budy.startsWith("$")) {
			if (!isOwner) return
				exec(q,
					(err, stdout) => {
						if (err) return m.reply(err.toString());
						if (stdout) return m.reply(stdout.toString());
				})
				}
		}
		
	} catch (e) {
		console.log(e)
	}
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(`Update ${__filename}`)
	delete require.cache[file]
	require(file)
})
