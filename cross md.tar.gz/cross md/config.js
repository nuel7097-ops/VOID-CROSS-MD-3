/*
┏━━━━━━━━━━━━━━━┓
┃     𝐌𝐑.𝐂𝐑𝐎𝐒𝐒𝐓𝐄𝐂𝐇
┣━━━━━━━━━━━━━━━┛
┃whatsapp :+2348063898506
┃owner : 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒
┃base : 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒
┃best friend : 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒 / 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒 dev
┃helper : my brain😂😂
┃maintainer : 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒
┃deals : t.me/cross006
┃pterodactyl hosting buy from 𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒 dev
┗━━━━━━━━━━━━━━━┛
*/
global.owner = ['2348063898506'] // owner number
global.connect = true // set to false if you want to connect bot using QR code.
global.autoonline = true;
  global.detectCall = true;
  global.welcome = false;
  global.public = true;
global.url = "https://t.me/cross006"
global.url2 = "https://t.me/cross006"
global.packname = "slayqueen md"
global.author = "𝐃𝐄𝐕-𝐈𝐋༄𝐌𝐑.𝐂𝐑𝐎𝐒𝐒"